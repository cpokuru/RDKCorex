# If not stated otherwise in this file or this component's LICENSE file the
# following copyright and licenses apply:
#
# Copyright 2023 RDK Management
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import shutil
from pathlib import Path
import textwrap


ROOT = Path(__file__).parent
# In the consolidated repo, this script lives in components/ and writes its
# output there directly (as full-list.html) rather than into a docs/
# subfolder — components/ IS the served directory for this page.
DOCS_DIR = ROOT
HTML_PATH = DOCS_DIR / "full-list.html"
# GitHub Pages (when publishing from /docs) only serves files inside docs/.
# sync_workbook() below makes sure the .xlsx ends up there regardless of
# whether you keep your working copy in docs/ or at the repo root.


CSS = textwrap.dedent(
    r'''
    :root {
      /* Brand */
      --brand-primary: #1a56db;
      --brand-secondary: #0e9f6e;
      --brand-accent: #7c3aed;

      /* Legacy aliases kept for backward-compat with JS/inline styles */
      --brand-navy: #1e3a5f;
      --brand-teal: #1a56db;
      --accent-amber: #d97706;
      --success: #0e9f6e;
      --danger: #dc2626;

      /* Surfaces */
      --bg-primary: #ffffff;
      --bg-secondary: #f3f4f6;
      --bg-card: #ffffff;
      --bg-base: #f9fafb;
      --bg-hover: #eff6ff;
      --bg-selected: #dbeafe;

      /* Nav */
      --nav-bg: linear-gradient(135deg, #1e3a5f 0%, #1a56db 100%);

      /* Text */
      --text-primary: #111827;
      --text-secondary: #374151;
      --text-muted: #9ca3af;
      --text-on-brand: #ffffff;

      /* Borders */
      --border: #e5e7eb;
      --border-subtle: #e5e7eb;
      --border-medium: #d1d5db;

      /* Semantic */
      --color-required: #065f46;
      --bg-required: #d1fae5;
      --color-optional: #92400e;
      --bg-optional: #fef3c7;
      --color-deprecated: #991b1b;
      --bg-deprecated: #fee2e2;
      --color-link: #1d4ed8;

      /* Shadows */
      --shadow-xs: 0 1px 2px rgba(0,0,0,0.05);
      --shadow-sm: 0 1px 3px rgba(0,0,0,0.1), 0 1px 2px rgba(0,0,0,0.06);
      --shadow-md: 0 4px 6px rgba(0,0,0,0.07), 0 2px 4px rgba(0,0,0,0.06);
      --shadow-lg: 0 10px 15px rgba(0,0,0,0.1), 0 4px 6px rgba(0,0,0,0.05);
      --shadow-xl: 0 20px 25px rgba(0,0,0,0.1), 0 10px 10px rgba(0,0,0,0.04);

      /* Radii */
      --radius-xs: 4px;
      --radius-sm: 6px;
      --radius-md: 8px;
      --radius-lg: 12px;
      --radius-xl: 16px;
      --radius-full: 9999px;

      --nav-h: 64px;
      --sidebar-w: 272px;
      --transition: 0.15s ease;
    }
    [data-theme="dark"] {
      --bg-base: #0f172a;
      --bg-primary: #1e293b;
      --bg-secondary: #0f172a;
      --bg-card: #1e293b;
      --bg-hover: #1e3a5f;
      --bg-selected: #1e3a5f;
      --text-primary: #f8fafc;
      --text-secondary: #cbd5e1;
      --text-muted: #64748b;
      --border: #334155;
      --border-subtle: #1e293b;
      --border-medium: #334155;
      --nav-bg: linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%);
    }

    /* Reset & base */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    html { font-size: 16px; scroll-behavior: smooth; }
    body {
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
      background: var(--bg-base);
      color: var(--text-primary);
      transition: background var(--transition), color var(--transition);
      min-height: 100vh;
      line-height: 1.6;
    }

    /* Progress bar — 4px tri-colour gradient */
    #progress-bar {
      position: fixed; top: 0; left: 0; height: 4px; width: 0%;
      background: linear-gradient(90deg, #1a56db, #0e9f6e, #7c3aed);
      z-index: 9999;
      transition: width 0.2s ease;
    }

    /* Nav — deep gradient + glow */
    #nav {
      position: sticky; top: 0; z-index: 100;
      height: var(--nav-h);
      background: var(--nav-bg);
      display: flex; align-items: center; gap: 12px;
      padding: 0 20px;
      box-shadow: 0 4px 20px rgba(26,86,219,0.2);
    }
    #nav .logo { display: flex; align-items: center; gap: 10px; text-decoration: none; }
    #nav .logo-icon {
      width: 38px; height: 38px;
      background: linear-gradient(135deg, #1a56db, #7c3aed);
      border-radius: var(--radius-full); display: grid; place-items: center; font-size: 18px;
      box-shadow: 0 2px 8px rgba(26,86,219,0.4);
    }
    #nav .logo-text { color: #fff; font-weight: 700; font-size: 1.1rem; }
    #nav .spacer { flex: 1; }
    /* Pill-shaped glassmorphism nav buttons */
    .nav-btn {
      background: rgba(255,255,255,0.12); border: 1px solid rgba(255,255,255,0.2);
      color: #fff; border-radius: var(--radius-full); cursor: pointer;
      font-size: 0.8rem; padding: 7px 16px; display: flex; align-items: center; gap: 6px;
      transition: all var(--transition);
      white-space: nowrap;
      backdrop-filter: blur(8px);
    }
    .nav-btn:hover { background: rgba(255,255,255,0.25); border-color: rgba(255,255,255,0.4); }
    .nav-btn:focus { outline: 2px solid #fff; outline-offset: 2px; }
    #dark-toggle { font-size: 1.1rem; padding: 7px 12px; }

    /* Toast — colour-coded with left border */
    #toast-container {
      position: fixed; bottom: 24px; right: 24px; z-index: 9000;
      display: flex; flex-direction: column; gap: 8px;
    }
    .toast {
      background: var(--bg-card); color: var(--text-primary);
      padding: 12px 18px; border-radius: var(--radius-lg);
      font-size: 0.875rem; box-shadow: var(--shadow-lg);
      animation: slideInRight 0.25s ease, fadeOut 0.3s ease 2.5s forwards;
      display: flex; align-items: center; gap: 8px;
      border-left: 4px solid var(--brand-primary);
      min-width: 240px;
    }
    .toast.success { border-left-color: #0e9f6e; }
    .toast.error { border-left-color: #dc2626; }
    .toast.info { border-left-color: #1a56db; }
    @keyframes slideInRight {
      from { transform: translateX(100px); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    @keyframes fadeOut { to { opacity: 0; transform: translateY(10px); } }

    /* Layout */
    #app {
      display: flex; height: calc(100vh - var(--nav-h));
      position: relative;
    }

    /* Sidebar */
    #sidebar {
      width: var(--sidebar-w); flex-shrink: 0;
      background: var(--bg-card);
      border-right: 1px solid var(--border);
      overflow-y: auto;
      transition: width var(--transition), transform var(--transition);
      display: flex; flex-direction: column;
    }
    #sidebar.collapsed { width: 0; overflow: hidden; }
    .sidebar-section {
      padding: 16px;
      border-bottom: 1px solid var(--border);
    }
    /* Section titles with coloured left-border accent */
    .sidebar-title {
      font-size: 0.7rem; font-weight: 700; text-transform: uppercase;
      letter-spacing: 0.08em; color: var(--brand-primary);
      margin-bottom: 10px;
      padding-left: 8px;
      border-left: 3px solid var(--brand-primary);
    }
    .sidebar-toggle {
      position: absolute; left: var(--sidebar-w); top: 12px; z-index: 10;
      width: 24px; height: 24px; background: var(--bg-card);
      border: 1px solid var(--border); border-left: none;
      border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
      cursor: pointer; display: grid; place-items: center;
      font-size: 0.75rem; color: var(--text-secondary);
      transition: left var(--transition);
    }
    #sidebar.collapsed ~ .sidebar-toggle { left: 0; }

    /* Main content */
    #main { flex: 1; display: flex; flex-direction: column; overflow: hidden; }

    /* Sheet tabs — segmented-control style */
    #sheet-tabs {
      display: flex; gap: 0; padding: 12px 20px 0;
      border-bottom: 2px solid var(--border);
      background: var(--bg-card);
      overflow-x: auto;
    }
    .tab-pill {
      padding: 8px 20px; border-radius: 0;
      cursor: pointer; font-size: 0.875rem; font-weight: 500;
      border: 1px solid var(--border); border-bottom: none;
      color: var(--text-secondary); background: var(--bg-secondary);
      transition: all var(--transition); white-space: nowrap;
      margin-right: -1px;
    }
    .tab-pill:first-child { border-radius: var(--radius-sm) 0 0 0; }
    .tab-pill:last-child { border-radius: 0 var(--radius-sm) 0 0; margin-right: 0; }
    .tab-pill.active {
      background: var(--brand-primary); color: #fff;
      border-color: var(--brand-primary); font-weight: 700;
      box-shadow: 0 -2px 8px rgba(26,86,219,0.2);
      position: relative; z-index: 1;
    }
    .tab-pill:hover:not(.active) { background: var(--bg-hover); color: var(--text-primary); }

    /* Content area */
    #content-area { flex: 1; overflow-y: auto; padding: 16px 20px; background: var(--bg-base); }

    /* Stat cards — coloured left-border accent + gradient text value */
    #stat-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 12px; margin-bottom: 16px; }
    .stat-card {
      background: var(--bg-card); border: 1px solid var(--border);
      border-radius: var(--radius-lg); padding: 16px;
      box-shadow: var(--shadow-sm);
      transition: transform var(--transition), box-shadow var(--transition);
      position: relative; overflow: hidden;
    }
    .stat-card::before {
      content: ''; position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
      background: var(--card-accent, var(--brand-primary));
      border-radius: var(--radius-lg) 0 0 var(--radius-lg);
    }
    .stat-card:nth-child(1) { --card-accent: #1a56db; }
    .stat-card:nth-child(2) { --card-accent: #0e9f6e; }
    .stat-card:nth-child(3) { --card-accent: #7c3aed; }
    .stat-card:nth-child(4) { --card-accent: #d97706; }
    .stat-card:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); }
    .stat-label { font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 4px; }
    .stat-value {
      font-size: 2.2rem; font-weight: 800; line-height: 1.1;
      background: linear-gradient(135deg, var(--card-accent, #1a56db), var(--brand-accent));
      -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
    }
    .stat-sub { font-size: 0.75rem; color: var(--text-secondary); margin-top: 2px; }

    /* Charts — gradient top strip + prominent title */
    #charts-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; }
    .chart-card {
      background: var(--bg-card); border: 1px solid var(--border);
      border-radius: var(--radius-lg); overflow: hidden; box-shadow: var(--shadow-sm); min-height: 200px;
    }
    .chart-card::before {
      content: ''; display: block; height: 4px;
      background: linear-gradient(90deg, #1a56db, #0e9f6e, #7c3aed);
    }
    .chart-title {
      font-size: 0.9rem; font-weight: 700; color: var(--text-primary);
      padding: 12px 16px 8px; letter-spacing: 0.02em;
    }
    canvas { display: block; padding: 0 8px 12px; }

    /* Toolbar — pill search, separated from content */
    #toolbar {
      display: flex; gap: 10px; align-items: center; flex-wrap: wrap;
      margin-bottom: 12px;
      padding: 10px 12px;
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: var(--radius-lg);
      box-shadow: var(--shadow-xs);
    }
    #search-wrapper { position: relative; flex: 1; min-width: 200px; }
    #search-input {
      width: 100%; height: 40px; padding: 0 16px 0 44px;
      border: 1.5px solid var(--border); border-radius: var(--radius-full);
      background: var(--bg-card); color: var(--text-primary);
      font-size: 0.875rem; font-family: inherit;
      transition: border-color var(--transition), box-shadow var(--transition);
    }
    #search-input:focus { outline: none; border-color: var(--brand-primary); box-shadow: 0 0 0 3px rgba(26,86,219,0.12); }
    /* Coloured circle search icon */
    .search-icon {
      position: absolute; left: 8px; top: 50%; transform: translateY(-50%);
      width: 26px; height: 26px; background: var(--brand-primary);
      border-radius: var(--radius-full); display: grid; place-items: center;
      font-size: 0.72rem; pointer-events: none; color: #fff;
    }
    #search-history { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 8px; }
    .history-chip {
      background: var(--bg-secondary); border: 1px solid var(--border);
      border-radius: var(--radius-full); padding: 3px 10px; font-size: 0.75rem;
      cursor: pointer; color: var(--text-secondary);
      transition: all var(--transition);
    }
    .history-chip:hover { background: var(--brand-primary); color: #fff; border-color: var(--brand-primary); }
    #sr-announce { position: absolute; width: 1px; height: 1px; clip: rect(0,0,0,0); overflow: hidden; }

    /* Toolbar buttons */
    .toolbar-btn {
      padding: 8px 16px; border-radius: var(--radius-md); cursor: pointer;
      font-size: 0.8rem; font-weight: 500; display: flex; align-items: center; gap: 6px;
      border: 1.5px solid var(--border); background: var(--bg-card); color: var(--text-primary);
      transition: all var(--transition); white-space: nowrap;
    }
    .toolbar-btn:hover { background: var(--bg-hover); border-color: var(--border-medium); }
    .toolbar-btn:focus { outline: 2px solid var(--brand-primary); outline-offset: 2px; }
    .toolbar-btn.primary { background: var(--brand-primary); color: #fff; border-color: var(--brand-primary); }
    .toolbar-btn.primary:hover { filter: brightness(1.1); }

    /* Column visibility panel */
    .col-vis-panel {
      background: var(--bg-card); border: 1px solid var(--border);
      border-radius: var(--radius-md); padding: 12px; margin-bottom: 10px;
      display: flex; flex-wrap: wrap; gap: 8px;
    }
    .col-toggle-chip {
      padding: 4px 12px; border-radius: var(--radius-full); font-size: 0.75rem;
      cursor: pointer; border: 1px solid var(--border);
      background: var(--bg-secondary); color: var(--text-secondary);
      user-select: none; transition: all var(--transition);
    }
    .col-toggle-chip.active { background: var(--brand-primary); color: #fff; border-color: var(--brand-primary); }

    /* Pagination — circular buttons */
    #pagination {
      display: flex; align-items: center; gap: 6px;
      padding: 12px 0; justify-content: flex-end; flex-wrap: wrap;
    }
    .page-btn {
      width: 32px; height: 32px; border-radius: var(--radius-full);
      border: 1.5px solid var(--border); background: var(--bg-card);
      cursor: pointer; color: var(--text-primary);
      font-size: 0.8rem; transition: all var(--transition);
      display: grid; place-items: center; padding: 0;
    }
    .page-btn:hover { background: var(--bg-hover); border-color: var(--brand-primary); }
    .page-btn.active { background: var(--brand-primary); color: #fff; border-color: var(--brand-primary); box-shadow: var(--shadow-sm); }
    .page-btn:disabled { opacity: 0.4; cursor: default; }
    #rows-per-page { padding: 5px 8px; border: 1.5px solid var(--border); border-radius: var(--radius-sm); background: var(--bg-card); color: var(--text-primary); font-size: 0.8rem; }

    /* Table wrapper */
    #table-wrapper {
      overflow-x: auto; overflow-y: auto;
      border: 1px solid var(--border); border-radius: var(--radius-lg);
      background: var(--bg-card); box-shadow: var(--shadow-sm);
      max-height: calc(100vh - 400px);
      position: relative;
    }
    #data-table { border-collapse: collapse; width: 100%; font-size: 0.875rem; }
    /* Header — gradient matching nav */
    #data-table thead th {
      position: sticky; top: 0; z-index: 5;
      background: linear-gradient(135deg, #1e3a5f 0%, #1a56db 100%); color: #fff;
      padding: 11px 12px; text-align: left; white-space: nowrap;
      user-select: none; cursor: pointer; font-weight: 700;
      font-size: 0.75rem; letter-spacing: 0.05em; text-transform: uppercase;
      border-right: 1px solid rgba(255,255,255,0.1);
    }
    #data-table thead th:first-child { position: sticky; left: 0; z-index: 6; }
    #data-table thead th:hover { background: linear-gradient(135deg, #162d50 0%, #1248c0 100%); }
    .sort-badge {
      display: inline-flex; align-items: center; justify-content: center;
      width: 16px; height: 16px; border-radius: 50%;
      background: #0e9f6e; color: #fff; font-size: 0.65rem;
      font-weight: 700; margin-left: 4px;
    }
    .sort-arrow { margin-left: 4px; opacity: 0.6; }

    /* Heatmap header row */
    .heatmap-row th {
      background: var(--bg-secondary) !important; color: var(--text-secondary) !important;
      font-size: 0.7rem; padding: 4px 12px !important; cursor: default !important;
      border-right: 1px solid var(--border) !important;
      text-transform: none !important; letter-spacing: 0 !important;
    }

    /* Column resize handle */
    .col-resize {
      position: absolute; right: 0; top: 0; bottom: 0; width: 4px;
      cursor: col-resize; background: transparent;
    }
    .col-resize:hover, .col-resize.active { background: var(--brand-primary); }

    /* Table body */
    #data-table tbody tr {
      border-bottom: 1px solid var(--border);
      transition: box-shadow var(--transition), background var(--transition);
    }
    /* Very subtle alternating stripe */
    #data-table tbody tr:nth-child(even) { background: rgba(59,130,246,0.03); }
    /* Row hover: left border flash + blue tint */
    #data-table tbody tr:hover {
      background: var(--bg-hover);
      box-shadow: inset 2px 0 0 var(--brand-primary);
    }
    #data-table tbody td {
      padding: 9px 12px; vertical-align: top; max-width: 240px;
      border-right: 1px solid var(--border);
      line-height: 1.6;
    }
    /* Sticky first column with elevation shadow */
    #data-table tbody td:first-child {
      position: sticky; left: 0; background: var(--bg-card); z-index: 1;
      box-shadow: 2px 0 8px rgba(0,0,0,0.08);
    }
    #data-table tbody tr:hover td:first-child { background: var(--bg-hover); }

    /* Cell truncate */
    .cell-text { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; word-break: break-word; }
    /* Cell expand — small blue pill */
    .cell-expand-btn {
      color: var(--brand-primary); cursor: pointer; font-size: 0.72rem;
      display: none;
      background: rgba(26,86,219,0.1); border-radius: var(--radius-full);
      padding: 1px 7px;
    }
    td:hover .cell-expand-btn { display: inline; }

    /* Cell popover */
    #cell-popover {
      position: fixed; z-index: 500; max-width: 360px;
      background: var(--bg-card); border: 1px solid var(--border);
      border-radius: var(--radius-lg); padding: 14px; box-shadow: var(--shadow-lg);
      font-size: 0.875rem; word-break: break-word;
      display: none;
    }
    #cell-popover.visible { display: block; }
    #cell-popover-close { float: right; cursor: pointer; color: var(--text-muted); margin-left: 8px; }

    /* Group rows */
    .group-row {
      background: var(--bg-secondary) !important;
      font-weight: 700; cursor: pointer;
    }
    .group-row td { color: #1a56db; padding: 8px 12px !important; }
    [data-theme="dark"] .group-row td { color: #60a5fa; }
    .group-row td:first-child { display: flex; align-items: center; gap: 8px; }
    .group-badge { background: var(--brand-primary); color: #fff; border-radius: var(--radius-full); padding: 1px 8px; font-size: 0.7rem; }
    .group-chevron { transition: transform var(--transition); display: inline-block; }
    .group-row.collapsed .group-chevron { transform: rotate(-90deg); }

    /* Compare mode */
    .row-compare-cb { width: 14px; height: 14px; cursor: pointer; accent-color: var(--brand-primary); }
    /* Compare FAB — gradient background */
    #compare-fab {
      position: fixed; bottom: 80px; right: 24px; z-index: 400;
      background: linear-gradient(135deg, #1a56db, #7c3aed); color: #fff;
      padding: 14px 24px; border-radius: var(--radius-full); cursor: pointer;
      font-weight: 700; box-shadow: var(--shadow-lg); display: none;
      align-items: center; gap: 8px; font-size: 0.9rem;
      animation: popIn 0.25s ease;
    }
    @keyframes popIn { from { transform: scale(0.8); opacity: 0; } to { transform: scale(1); opacity: 1; } }

    /* Compare panel */
    #compare-panel {
      position: fixed; top: var(--nav-h); right: 0; bottom: 0; width: 480px; max-width: 95vw;
      background: var(--bg-card); border-left: 1px solid var(--border);
      z-index: 300; transform: translateX(100%);
      transition: transform var(--transition); overflow-y: auto;
      box-shadow: var(--shadow-lg); padding: 20px;
    }
    #compare-panel.open { transform: translateX(0); }
    #compare-panel h3 { margin-bottom: 16px; color: var(--text-primary); }
    .compare-col { font-size: 0.78rem; }
    .compare-col strong { color: var(--brand-primary); }
    .compare-diff { background: rgba(217,119,6,0.15); border-radius: 4px; padding: 1px 4px; }

    /* Command palette — blurred backdrop + gradient accent strip */
    #cmd-overlay {
      position: fixed; inset: 0; background: rgba(0,0,0,0.6);
      backdrop-filter: blur(4px);
      z-index: 800; display: none; align-items: flex-start; justify-content: center;
      padding-top: 80px;
    }
    #cmd-overlay.open { display: flex; }
    #cmd-modal {
      background: var(--bg-card); border: 1px solid var(--border);
      border-radius: var(--radius-xl); width: 580px; max-width: 95vw;
      box-shadow: var(--shadow-xl); overflow: hidden;
    }
    #cmd-modal::before {
      content: ''; display: block; height: 4px;
      background: linear-gradient(90deg, #1a56db, #0e9f6e, #7c3aed);
    }
    #cmd-input {
      width: 100%; padding: 18px 20px; font-size: 1.1rem;
      border: none; background: transparent; color: var(--text-primary); font-family: inherit;
      border-bottom: 1px solid var(--border);
    }
    #cmd-input:focus { outline: none; }
    #cmd-results { max-height: 400px; overflow-y: auto; padding: 8px 0; }
    /* Selected item gets blue left border + light bg */
    .cmd-item {
      display: flex; align-items: center; gap: 12px;
      padding: 10px 20px; cursor: pointer; font-size: 0.9rem;
      transition: background var(--transition);
      border-left: 3px solid transparent;
    }
    .cmd-item:hover, .cmd-item.selected {
      background: var(--bg-hover);
      border-left-color: var(--brand-primary);
    }
    .cmd-item .cmd-icon { width: 32px; height: 32px; background: var(--bg-secondary); border-radius: var(--radius-sm); display: grid; place-items: center; flex-shrink: 0; font-size: 1rem; }
    .cmd-item .cmd-name { font-weight: 600; }
    .cmd-item .cmd-desc { font-size: 0.78rem; color: var(--text-muted); }
    .cmd-group-label { padding: 8px 20px; font-size: 0.7rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--text-muted); }

    /* Filter dropdowns in column headers */
    .col-filter-select {
      display: block; width: calc(100% - 4px); margin-top: 4px;
      font-size: 0.7rem; padding: 2px 4px; border-radius: 4px;
      border: 1px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.15);
      color: #fff; cursor: pointer;
    }
    .col-filter-select option { color: var(--text-primary); background: var(--bg-card); }

    /* Global search results panel */
    #global-search-panel {
      background: var(--bg-card); border: 1px solid var(--border);
      border-radius: var(--radius-md); padding: 12px; margin-bottom: 12px;
      display: none;
    }
    #global-search-panel.visible { display: block; }
    .global-sheet-group { margin-bottom: 10px; }
    .global-sheet-label { font-size: 0.8rem; font-weight: 700; color: var(--text-primary); margin-bottom: 4px; display: flex; align-items: center; gap: 8px; }
    .global-badge { background: var(--brand-primary); color: #fff; border-radius: var(--radius-full); padding: 1px 8px; font-size: 0.7rem; }
    .global-result-row { font-size: 0.78rem; color: var(--text-secondary); padding: 3px 0; cursor: pointer; }
    .global-result-row:hover { color: var(--brand-primary); }
    mark { background: rgba(245,158,11,0.3); color: inherit; border-radius: 2px; }

    /* Skeleton shimmer */
    .skeleton {
      animation: shimmer 1.5s infinite;
      background: linear-gradient(90deg, var(--bg-secondary) 25%, var(--bg-hover) 50%, var(--bg-secondary) 75%);
      background-size: 200% 100%;
      border-radius: var(--radius-sm); height: 14px; margin: 4px 0;
    }
    @keyframes shimmer { to { background-position: -200% 0; } }

/* Workbook load / drop panel */
#workbook-load-panel { display: none; padding: 40px 16px; }
#workbook-drop-zone {
  border: 2px dashed var(--border-medium);
  border-radius: var(--radius-lg);
  background: var(--bg-card);
  padding: 56px 24px;
  text-align: center;
  max-width: 560px;
  margin: 0 auto;
  cursor: pointer;
  transition: border-color var(--transition), background var(--transition);
}
#workbook-drop-zone:hover, #workbook-drop-zone:focus, #workbook-drop-zone.dragover {
  border-color: var(--brand-primary);
  background: var(--bg-hover);
  outline: none;
}
#workbook-drop-zone .wlp-icon { font-size: 2.5rem; margin-bottom: 12px; }
#workbook-drop-zone .wlp-title { font-size: 1.05rem; font-weight: 700; color: var(--text-primary); margin-bottom: 6px; }
#workbook-drop-zone .wlp-sub { font-size: 0.85rem; color: var(--text-muted); margin-bottom: 18px; line-height: 1.5; }
#workbook-drop-zone.wlp-error .wlp-sub { color: var(--danger); }

    /* Link cells — button-style with external icon */
    .cell-link {
      color: var(--color-link); text-decoration: none;
      font-size: 0.75rem; font-weight: 500;
      display: inline-flex; align-items: center; gap: 3px;
    }
    .cell-link::after { content: '\2197'; font-size: 0.65rem; opacity: 0.7; }
    .cell-link:hover { text-decoration: underline; color: var(--brand-primary); }

    /* Status badges — vivid pill-shaped */
    .status-badge {
      display: inline-block; padding: 3px 10px; border-radius: var(--radius-full);
      font-size: 0.72rem; font-weight: 600;
    }
    .status-required { background: var(--bg-required); color: var(--color-required); }
    .status-optional { background: var(--bg-optional); color: var(--color-optional); }
    .status-deprecated { background: var(--bg-deprecated); color: var(--color-deprecated); }

    /* Extra sidebar polish */
    .sidebar-meta-grid { display: grid; gap: 10px; }
    .sidebar-meta-card {
      border: 1px solid var(--border);
      background: var(--bg-secondary);
      border-radius: var(--radius-md);
      padding: 12px;
      box-shadow: var(--shadow-xs);
    }
    .sidebar-meta-label {
      font-size: 0.72rem;
      color: var(--text-muted);
      text-transform: uppercase;
      letter-spacing: 0.06em;
      margin-bottom: 6px;
    }
    .sidebar-meta-value { font-size: 0.95rem; font-weight: 700; color: var(--text-primary); }
    .sidebar-meta-sub { font-size: 0.75rem; color: var(--text-secondary); margin-top: 4px; }
    .sidebar-list { display: flex; flex-direction: column; gap: 8px; }
    /* Sidebar sheet buttons — rounded card with brand-pill row count */
    .sidebar-sheet-btn {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      width: 100%;
      border: 1px solid var(--border);
      background: var(--bg-secondary);
      color: var(--text-primary);
      border-radius: var(--radius-md);
      padding: 10px 12px;
      cursor: pointer;
      font: inherit;
      transition: all var(--transition);
      text-align: left;
    }
    .sidebar-sheet-btn:hover { background: var(--bg-hover); border-color: var(--brand-primary); }
    /* Active sheet: 3px left border + tint */
    .sidebar-sheet-btn.active {
      border-left: 3px solid var(--brand-primary);
      background: rgba(26,86,219,0.06);
      color: var(--brand-primary);
    }
    .sidebar-sheet-name { font-size: 0.82rem; font-weight: 600; }
    /* Row count in brand-colour pill */
    .sidebar-sheet-count {
      font-size: 0.72rem;
      color: #fff;
      padding: 2px 8px;
      border-radius: var(--radius-full);
      background: var(--brand-primary);
      flex-shrink: 0;
    }
    .sidebar-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .sidebar-action-btn {
      padding: 8px 10px;
      border-radius: var(--radius-md);
      border: 1px solid var(--border);
      background: var(--bg-secondary);
      color: var(--text-primary);
      cursor: pointer;
      font: inherit;
      font-size: 0.78rem;
      transition: all var(--transition);
    }
    .sidebar-action-btn:hover { background: var(--bg-hover); }
    .sidebar-pill-row { display: flex; flex-wrap: wrap; gap: 6px; }
    .sidebar-filter-pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 5px 10px;
      border-radius: var(--radius-full);
      border: 1px solid var(--border);
      background: var(--bg-secondary);
      color: var(--text-secondary);
      font-size: 0.74rem;
    }
    .sidebar-legend { display: grid; gap: 8px; }
    .legend-item { display: flex; align-items: center; gap: 8px; font-size: 0.78rem; color: var(--text-secondary); }
    .legend-dot { width: 10px; height: 10px; border-radius: var(--radius-full); display: inline-block; }
    .sidebar-empty { font-size: 0.76rem; color: var(--text-muted); line-height: 1.45; }
    .kbd {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 22px;
      height: 22px;
      padding: 0 6px;
      border-radius: 6px;
      border: 1px solid var(--border);
      background: var(--bg-secondary);
      font-size: 0.72rem;
      color: var(--text-secondary);
    }
    .section-note {
      font-size: 0.76rem;
      color: var(--text-secondary);
      line-height: 1.5;
    }
    .compare-grid { display: grid; gap: 12px; }
    .compare-field { margin-bottom: 10px; }
    .compare-value { margin-top: 4px; line-height: 1.5; }


    /* Advanced UX polish */
    #nav {
      position: sticky;
      isolation: isolate;
    }
    #nav::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      height: 2px;
      background: linear-gradient(90deg, #3b82f6, #10b981, #8b5cf6, #f59e0b, #3b82f6);
      background-size: 200% 100%;
      animation: navBorder 4s linear infinite;
    }
    @keyframes navBorder {
      0% { background-position: 0% 0%; }
      100% { background-position: 200% 0%; }
    }
    #nav .logo-text {
      font-size: 1rem;
      font-weight: 800;
      letter-spacing: -0.02em;
    }
    #nav-breadcrumb {
      color: rgba(255,255,255,0.68);
      font-size: 0.8rem;
      margin-left: 4px;
      white-space: nowrap;
    }

    #welcome-banner {
      margin-bottom: 16px;
      border-radius: var(--radius-xl);
      background: linear-gradient(135deg, #1e3a5f, #1a56db);
      color: #fff;
      box-shadow: var(--shadow-lg);
      overflow: hidden;
      transition: max-height 0.3s ease, opacity 0.25s ease, transform 0.25s ease, margin-bottom 0.25s ease;
      max-height: 240px;
      opacity: 1;
    }
    #welcome-banner.dismissed {
      max-height: 0;
      opacity: 0;
      margin-bottom: 0;
      transform: translateY(-10px);
      overflow: hidden;
      pointer-events: none;
    }
    .welcome-content {
      display: grid;
      grid-template-columns: auto 1fr auto;
      gap: 16px;
      align-items: center;
      padding: 20px 22px;
    }
    .welcome-icon {
      width: 52px;
      height: 52px;
      display: grid;
      place-items: center;
      border-radius: 18px;
      background: rgba(255,255,255,0.14);
      box-shadow: inset 0 1px 0 rgba(255,255,255,0.18);
      font-size: 1.6rem;
    }
    .welcome-title {
      font-size: 1.18rem;
      font-weight: 800;
      letter-spacing: -0.03em;
      margin-bottom: 4px;
    }
    .welcome-sub {
      color: rgba(255,255,255,0.82);
      font-size: 0.92rem;
      max-width: 70ch;
    }
    .welcome-chips {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 14px;
    }
    .welcome-chip {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 10px;
      border-radius: var(--radius-full);
      background: rgba(255,255,255,0.14);
      border: 1px solid rgba(255,255,255,0.18);
      font-size: 0.76rem;
      font-weight: 600;
      backdrop-filter: blur(8px);
    }
    #dismiss-banner {
      width: 34px;
      height: 34px;
      border: none;
      border-radius: var(--radius-full);
      background: rgba(255,255,255,0.14);
      color: #fff;
      cursor: pointer;
      font-size: 1rem;
      transition: background var(--transition), transform var(--transition);
    }
    #dismiss-banner:hover {
      background: rgba(255,255,255,0.22);
      transform: scale(1.04);
    }

    #stat-cards {
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    }
    .stat-card {
      border-radius: var(--radius-lg);
      padding: 18px 20px;
      border: 1px solid var(--border);
      border-left: 4px solid var(--card-accent, var(--brand-primary));
      box-shadow: var(--shadow-sm);
      transition: transform 0.2s ease, box-shadow 0.2s ease;
      position: relative;
      overflow: hidden;
      cursor: default;
      background-image:
        radial-gradient(circle at top right, rgba(255,255,255,0.7), transparent 38%),
        repeating-linear-gradient(-45deg, rgba(148,163,184,0.08) 0 2px, transparent 2px 10px);
    }
    .stat-card::before { display: none; }
    .stat-card::after {
      content: '';
      position: absolute;
      top: -20px;
      right: -20px;
      width: 80px;
      height: 80px;
      background: var(--card-accent, var(--brand-primary));
      opacity: 0.05;
      border-radius: 50%;
    }
    .stat-card:hover {
      transform: translateY(-3px) scale(1.01);
      box-shadow: var(--shadow-md);
    }
    .stat-icon {
      width: 40px;
      height: 40px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      border-radius: 14px;
      background: rgba(255,255,255,0.9);
      border: 1px solid rgba(148,163,184,0.18);
      color: var(--card-accent, var(--brand-primary));
      margin-bottom: 10px;
    }
    [data-theme="dark"] .stat-icon {
      background: rgba(15,23,42,0.42);
      border-color: rgba(148,163,184,0.16);
    }
    .stat-label {
      font-size: 0.7rem;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin-bottom: 4px;
      color: var(--text-muted);
    }
    .stat-value {
      font-family: 'Inter', sans-serif;
      font-variant-numeric: tabular-nums;
      font-size: 2.4rem;
      font-weight: 900;
      letter-spacing: -0.03em;
      line-height: 1.05;
      background: none;
      -webkit-text-fill-color: currentColor;
      color: var(--text-primary);
    }
    .stat-sub { font-size: 0.76rem; }

    .chart-title {
      font-size: 0.95rem;
      font-weight: 700;
      letter-spacing: -0.01em;
    }

    #data-table thead th {
      font-size: 0.72rem;
      font-weight: 700;
      letter-spacing: 0.06em;
      text-transform: uppercase;
    }
    #data-table tbody td {
      font-family: 'Inter', sans-serif;
      font-size: 0.875rem;
      line-height: 1.6;
    }
    #data-table tbody td:nth-child(2) {
      color: var(--text-muted);
      font-size: 0.78rem;
      font-family: 'JetBrains Mono', monospace;
      min-width: 36px;
      text-align: center;
      background: var(--bg-secondary) !important;
    }
    #data-table tbody tr:hover td:nth-child(2) {
      background: var(--bg-secondary) !important;
    }
    #data-table tbody tr:nth-child(even) {
      background: rgba(59, 130, 246, 0.04);
    }
    .heatmap-row th {
      font-family: 'JetBrains Mono', monospace;
      font-variant-numeric: tabular-nums;
    }
    #empty-row td svg {
      margin: 0 auto;
      color: var(--brand-primary);
      opacity: 0.88;
    }

    .sidebar-title {
      font-size: 0.65rem;
      font-weight: 700;
      letter-spacing: 0.1em;
    }
    .sidebar-section-header {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 0;
      border: none;
      background: transparent;
      cursor: pointer;
      text-align: left;
      color: inherit;
    }
    .sidebar-section-body {
      margin-top: 10px;
      max-height: 1000px;
      overflow: hidden;
      transition: max-height 0.25s ease, opacity 0.2s ease, margin-top 0.2s ease;
    }
    .sidebar-section.collapsed .sidebar-section-body {
      max-height: 0;
      opacity: 0;
      margin-top: 0;
    }
    .sidebar-chevron {
      flex-shrink: 0;
      color: var(--text-muted);
      transition: transform var(--transition);
    }
    .sidebar-section.collapsed .sidebar-chevron {
      transform: rotate(-90deg);
    }
    .sidebar-sheet-btn {
      border-left: 2px solid transparent;
      padding-left: 11px;
    }
    .sidebar-filter-pill {
      padding-right: 6px;
    }
    .sidebar-filter-pill button {
      width: 20px;
      height: 20px;
      border: none;
      border-radius: var(--radius-full);
      background: rgba(26,86,219,0.12);
      color: var(--brand-primary);
      cursor: pointer;
      display: inline-grid;
      place-items: center;
      font-size: 0.82rem;
      line-height: 1;
    }
    .sidebar-filter-pill button:hover {
      background: rgba(26,86,219,0.18);
    }

    #page-footer {
      padding: 16px 20px;
      border-top: 1px solid var(--border);
      background: var(--bg-card);
      margin-top: 8px;
      border-radius: var(--radius-lg);
      box-shadow: var(--shadow-xs);
    }
    .footer-inner {
      display: flex;
      align-items: center;
      gap: 8px;
      flex-wrap: wrap;
      font-size: 0.78rem;
      color: var(--text-muted);
    }
    .footer-sep { color: var(--border-medium); }
    .footer-link {
      color: var(--brand-primary);
      text-decoration: none;
      font-weight: 600;
    }
    .footer-link:hover { text-decoration: underline; }

    #kbd-legend {
      position: fixed;
      left: 16px;
      bottom: 16px;
      z-index: 200;
      width: 190px;
      border: 1px solid rgba(255,255,255,0.22);
      border-radius: 16px;
      background: rgba(255,255,255,0.64);
      backdrop-filter: blur(16px);
      box-shadow: var(--shadow-lg);
      color: var(--text-primary);
      overflow: hidden;
      font-size: 0.72rem;
    }
    [data-theme="dark"] #kbd-legend {
      background: rgba(15,23,42,0.72);
      border-color: rgba(148,163,184,0.18);
    }
    .kbd-legend-toggle {
      width: 100%;
      border: none;
      background: transparent;
      color: inherit;
      cursor: pointer;
      text-align: left;
      padding: 10px 12px;
      font-size: 0.74rem;
      font-weight: 700;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .kbd-legend-body {
      max-height: 0;
      opacity: 0;
      overflow: hidden;
      transition: max-height 0.2s ease, opacity 0.2s ease;
      padding: 0 12px;
    }
    #kbd-legend.open .kbd-legend-body,
    #kbd-legend:hover .kbd-legend-body,
    #kbd-legend:focus-within .kbd-legend-body {
      max-height: 180px;
      opacity: 1;
      padding: 0 12px 12px;
    }
    .kbd-legend-body div {
      display: flex;
      justify-content: space-between;
      gap: 10px;
      color: var(--text-secondary);
      margin-top: 8px;
    }

    #scroll-top {
      position: fixed;
      left: 16px;
      bottom: 92px;
      width: 42px;
      height: 42px;
      border: none;
      border-radius: var(--radius-full);
      background: var(--brand-primary);
      color: #fff;
      box-shadow: var(--shadow-lg);
      cursor: pointer;
      z-index: 201;
      opacity: 0;
      pointer-events: none;
      transform: translateY(10px);
      transition: opacity 0.2s ease, transform 0.2s ease;
      font-size: 1rem;
    }
    #scroll-top.visible {
      opacity: 1;
      pointer-events: auto;
      transform: translateY(0);
    }


    /* Responsive */
    @media (max-width: 768px) {
      #sidebar { position: fixed; bottom: 0; left: 0; right: 0; top: auto; width: 100% !important; height: 50vh; z-index: 200; border-radius: var(--radius-lg) var(--radius-lg) 0 0; transform: translateY(100%); transition: transform var(--transition); }
      #sidebar.mobile-open { transform: translateY(0); }
      #charts-row { grid-template-columns: 1fr; }
      .nav-btn span { display: none; }
      #stat-cards { grid-template-columns: repeat(2, 1fr); }
      .sidebar-actions { grid-template-columns: 1fr; }
      #table-wrapper { max-height: none; }
      .welcome-content { grid-template-columns: 1fr; }
      #dismiss-banner { justify-self: start; }
      #kbd-legend { left: 12px; bottom: 12px; width: calc(100vw - 24px); max-width: 220px; }
      #scroll-top { left: auto; right: 16px; bottom: 24px; }
    }

    /* Print */
    @media print {
      #nav, #sidebar, #toolbar, #pagination, #charts-row, #stat-cards, .sidebar-toggle, #welcome-banner, #page-footer, #kbd-legend, #scroll-top { display: none !important; }
      #app { display: block; }
      #main { overflow: visible; }
      #table-wrapper { overflow: visible; border: none; max-height: none; }
      #data-table tbody td:first-child { position: static; }
      #data-table thead th:first-child { position: static; }
    }
    '''
).strip()


JS = textwrap.dedent(
    r'''
    // ===== State =====
    const state = {
      sheets: [],
      activeSheet: 0,
      sortCols: [],
      filters: {},
      colWidths: {},
      hiddenCols: new Set(),
      search: '',
      page: 1,
      pageSize: 250,
      groupBy: null,
      groupCollapsed: new Set(),
      compareRows: new Set(),
      searchHistory: [],
      filteredData: [],
      colFilters: {},
      globalSearch: false,
    };

    const PALETTE = [
      '#3b82f6','#10b981','#f59e0b','#8b5cf6','#ef4444',
      '#06b6d4','#f97316','#84cc16','#ec4899','#14b8a6',
      '#6366f1','#a855f7'
    ];
    let cmdItems = [];
    let cmdSelected = 0;

    // ===== Boot =====
    document.addEventListener('DOMContentLoaded', () => {
      initTheme();
      bindNav();
      bindKeyboard();
      initProgress();
      initSidebarSections();
      initWelcomeBanner();
      bindFloatingWidgets();
      loadData();
    });

    function initProgress() {
      const bar = document.getElementById('progress-bar');
      if (!bar) return;
      bar.style.width = '60%';
      setTimeout(() => {
        bar.style.width = '100%';
        setTimeout(() => { bar.style.opacity = '0'; }, 250);
      }, 200);
    }

    function initTheme() {
      const stored = localStorage.getItem('theme');
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      const theme = stored || (prefersDark ? 'dark' : 'light');
      document.documentElement.setAttribute('data-theme', theme);
      updateDarkToggleIcon(theme);
    }

    function toggleTheme() {
      const cur = document.documentElement.getAttribute('data-theme');
      const next = cur === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      localStorage.setItem('theme', next);
      updateDarkToggleIcon(next);
      renderCharts();
      toast('Switched to ' + next + ' mode');
    }

    function updateDarkToggleIcon(theme) {
      const btn = document.getElementById('dark-toggle');
      if (!btn) return;
      if (theme === 'dark') {
        btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>';
      } else {
        btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
      }
    }

    // ===== Data Loading =====
    // The workbook is parsed live in the browser (via SheetJS) instead of being baked
    // into the page at build time. To ship a new year's data, just replace the .xlsx
    // file sitting next to this HTML file — no regeneration step required.
    // If the filename changes, either update WORKBOOK_FILE below, or simply use the
    // "Load Workbook" button / drag-and-drop panel to pick the new file at runtime.
    const WORKBOOK_FILE = 'RDK-B_Component_List_2026.xlsx';

    function normalizeCell(v) {
      if (v === null || v === undefined) return '';
      return String(v).replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    }

    function parseWorkbookBuffer(buf) {
      if (typeof XLSX === 'undefined') throw new Error('XLSX library failed to load (check your network/CDN access)');
      const wb = XLSX.read(buf, { type: 'array' });
      return wb.SheetNames.map(name => {
        const ws = wb.Sheets[name];
        const aoa = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '', raw: false });
        const headers = (aoa[0] || []).map(normalizeCell);
        const rows = aoa.slice(1)
          .map(r => headers.map((_, i) => normalizeCell(r[i])))
          .filter(r => r.some(c => c.trim() !== ''));
        return { name, headers, rows };
      });
    }

    async function loadWorkbookFromUrl(url) {
      const res = await fetch(url, { cache: 'no-store' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const buf = await res.arrayBuffer();
      return parseWorkbookBuffer(buf);
    }

    async function loadWorkbookFromFile(file) {
      const buf = await file.arrayBuffer();
      return parseWorkbookBuffer(buf);
    }

    function deriveWorkbookLabel(sourceName) {
      const m = (sourceName || '').match(/(19|20)\d{2}/);
      return 'RDK-B Component List' + (m ? ' ' + m[0] : '');
    }

    function applyWorkbookLabel(label) {
      state.workbookLabel = label;
      document.title = label;
      const logo = document.querySelector('.logo-text');
      if (logo) logo.textContent = label;
      const welcomeTitle = document.querySelector('.welcome-title');
      if (welcomeTitle) welcomeTitle.textContent = label;
      const footerLabel = document.querySelector('#page-footer .footer-inner > span:first-child');
      if (footerLabel) footerLabel.textContent = label;
    }

    function loadData() {
      loadWorkbookFromUrl(WORKBOOK_FILE)
        .then(sheets => initWithSheets(sheets, WORKBOOK_FILE))
        .catch(err => {
          console.warn('Auto-load of "' + WORKBOOK_FILE + '" failed, falling back to manual picker:', err);
          showWorkbookLoadPanel('Could not auto-load "' + WORKBOOK_FILE + '". Drop the .xlsx file here, or click to browse.', true);
        });
    }

    function showWorkbookLoadPanel(message, isError) {
      document.getElementById('skeleton-loader').style.display = 'none';
      document.getElementById('main-content').style.display = 'none';
      const panel = document.getElementById('workbook-load-panel');
      const zone = document.getElementById('workbook-drop-zone');
      const msgEl = document.getElementById('workbook-load-msg');
      if (msgEl && message) msgEl.textContent = message;
      if (zone) zone.classList.toggle('wlp-error', !!isError);
      if (panel) panel.style.display = 'block';
    }

    function hideWorkbookLoadPanel() {
      const panel = document.getElementById('workbook-load-panel');
      if (panel) panel.style.display = 'none';
    }

    function bindWorkbookLoader() {
      const fileInput = document.getElementById('workbook-file-input');
      const dropZone = document.getElementById('workbook-drop-zone');
      const browseBtn = document.getElementById('workbook-drop-browse-btn');
      const navLoadBtn = document.getElementById('load-workbook-btn');

      const openPicker = () => fileInput.click();
      if (navLoadBtn) navLoadBtn.onclick = () => { showWorkbookLoadPanel('Drop an .xlsx file here, or click to browse.', false); };
      if (browseBtn) browseBtn.onclick = openPicker;
      if (dropZone) {
        dropZone.onclick = openPicker;
        dropZone.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openPicker(); } };
        dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.classList.add('dragover'); });
        dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
        dropZone.addEventListener('drop', (e) => {
          e.preventDefault();
          dropZone.classList.remove('dragover');
          if (e.dataTransfer.files && e.dataTransfer.files[0]) handleWorkbookFile(e.dataTransfer.files[0]);
        });
      }
      fileInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files[0]) handleWorkbookFile(e.target.files[0]);
      });
    }

    function handleWorkbookFile(file) {
      loadWorkbookFromFile(file)
        .then(sheets => {
          initWithSheets(sheets, file.name);
          toast('Loaded ' + file.name);
        })
        .catch(err => {
          console.error('Failed to parse workbook:', err);
          showWorkbookLoadPanel('Could not read "' + file.name + '" — make sure it\'s a valid .xlsx file.', true);
        });
    }

    function initWithSheets(sheets, sourceLabel) {
      if (!Array.isArray(sheets) || !sheets.length) throw new Error('Invalid workbook structure');
      state.sheets = sheets;
      applyWorkbookLabel(deriveWorkbookLabel(sourceLabel));
      hideWorkbookLoadPanel();

      const hash = parseHash();
      const maxIndex = Math.max(0, state.sheets.length - 1);
      state.activeSheet = Number.isFinite(hash.sheet) ? Math.min(Math.max(hash.sheet, 0), maxIndex) : 0;
      state.search = hash.q || '';
      document.getElementById('search-input').value = state.search;

      try {
        state.searchHistory = JSON.parse(localStorage.getItem('searchHistory') || '[]');
      } catch (e) {
        state.searchHistory = [];
      }

      renderSheetTabs();
      renderSearchHistory();
      switchSheet(state.activeSheet, false);

      document.getElementById('skeleton-loader').style.display = 'none';
      document.getElementById('main-content').style.display = 'block';
    }

    // ===== Hash / URL Sync =====
    function parseHash() {
      const h = location.hash.replace('#', '');
      const p = new URLSearchParams(h);
      const sheetParam = parseInt(p.get('sheet') || '0', 10);
      return { sheet: sheetParam, q: p.get('q') || '' };
    }

    function updateHash() {
      const p = new URLSearchParams();
      p.set('sheet', String(state.activeSheet));
      if (state.search) p.set('q', state.search);
      history.replaceState(null, '', '#' + p.toString());
    }

    function getActiveSheet() {
      return state.sheets[state.activeSheet];
    }

    function findSubsystemIndex(sheet = getActiveSheet()) {
      return sheet ? sheet.headers.findIndex(h => /sub-?system/i.test(h)) : -1;
    }

    function findStatusIndex(sheet = getActiveSheet()) {
      return sheet ? sheet.headers.findIndex(h => /status/i.test(h)) : -1;
    }

    // ===== Tabs =====
    function renderSheetTabs() {
      const container = document.getElementById('sheet-tabs');
      container.innerHTML = '';
      state.sheets.forEach((s, i) => {
        const btn = document.createElement('button');
        btn.className = 'tab-pill' + (i === state.activeSheet ? ' active' : '');
        btn.textContent = s.name;
        btn.setAttribute('role', 'tab');
        btn.setAttribute('aria-selected', String(i === state.activeSheet));
        btn.onclick = () => switchSheet(i);
        container.appendChild(btn);
      });
    }

    function switchSheet(idx, animate = true) {
      state.activeSheet = idx;
      state.page = 1;
      state.sortCols = [];
      state.colFilters = {};
      state.filters = {};
      state.compareRows.clear();
      state.groupCollapsed = new Set();
      state.hiddenCols = new Set();

      const sheet = getActiveSheet();
      state.groupBy = null;

      document.getElementById('search-input').value = state.search;
      updateNavBreadcrumb(sheet);
      updateFooterStats();
      renderSheetTabs();
      renderSidebar();
      updateHash();
      renderStats();
      renderColVisibility();
      applyFilters();
      renderCharts();
      updateCompareFab();
      updateGroupButton();

      if (animate) {
        const area = document.getElementById('content-area');
        if (area) area.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }

    function updateNavBreadcrumb(sheet = getActiveSheet()) {
      const el = document.getElementById('nav-breadcrumb');
      if (el && sheet) el.textContent = '› ' + sheet.name;
    }

    function updateFooterStats() {
      const el = document.getElementById('footer-stats');
      if (!el || !state.sheets.length) return;
      const total = state.sheets.reduce((sum, sh) => sum + sh.rows.length, 0);
      el.textContent = `${total} total components across ${state.sheets.length} profiles`;
    }

    function initWelcomeBanner() {
      const banner = document.getElementById('welcome-banner');
      const dismiss = document.getElementById('dismiss-banner');
      if (!banner || !dismiss) return;
      if (localStorage.getItem('bannerDismissed')) {
        banner.style.display = 'none';
        return;
      }
      dismiss.onclick = () => {
        localStorage.setItem('bannerDismissed', '1');
        banner.classList.add('dismissed');
        setTimeout(() => { banner.style.display = 'none'; }, 320);
      };
    }

    function bindFloatingWidgets() {
      const contentArea = document.getElementById('content-area');
      const scrollTopBtn = document.getElementById('scroll-top');
      if (contentArea) contentArea.addEventListener('scroll', updateScrollTopVisibility);
      if (scrollTopBtn) {
        scrollTopBtn.onclick = () => {
          if (contentArea) contentArea.scrollTo({ top: 0, behavior: 'smooth' });
        };
      }
      updateScrollTopVisibility();
    }

    function updateScrollTopVisibility() {
      const contentArea = document.getElementById('content-area');
      const btn = document.getElementById('scroll-top');
      if (!contentArea || !btn) return;
      btn.classList.toggle('visible', contentArea.scrollTop > 160);
    }

    function initSidebarSections() {
      document.querySelectorAll('#sidebar .sidebar-section').forEach((section) => {
        if (section.dataset.collapsibleInit === 'true') return;
        const title = section.querySelector('.sidebar-title');
        if (!title) return;

        const header = document.createElement('button');
        header.type = 'button';
        header.className = 'sidebar-section-header';
        section.insertBefore(header, title);
        header.appendChild(title);

        const chevron = document.createElement('span');
        chevron.className = 'sidebar-chevron';
        chevron.textContent = '▾';
        header.appendChild(chevron);

        const body = document.createElement('div');
        body.className = 'sidebar-section-body';
        while (header.nextSibling) body.appendChild(header.nextSibling);
        section.appendChild(body);

        header.addEventListener('click', () => {
          section.classList.toggle('collapsed');
        });
        section.dataset.collapsibleInit = 'true';
      });
    }

    // ===== Sidebar =====
    function renderSidebar() {
      renderSidebarSummary();
      renderSidebarSheets();
      renderSidebarQuickFilters();
      renderSidebarActiveView();
      updateSidebarToggle();
    }

    function renderSidebarSummary() {
      const sheet = getActiveSheet();
      const container = document.getElementById('sidebar-workbook-summary');
      if (!sheet) return;

      let filled = 0;
      let total = 0;
      sheet.rows.forEach(row => row.forEach(cell => {
        total += 1;
        if ((cell || '').toString().trim()) filled += 1;
      }));
      const fillRate = total ? Math.round((filled / total) * 100) : 0;

      container.innerHTML = `
        <div class="sidebar-meta-grid">
          <div class="sidebar-meta-card">
            <div class="sidebar-meta-label">Workbook</div>
            <div class="sidebar-meta-value">RDK-B Component List 2026</div>
            <div class="sidebar-meta-sub">${escHtml(sheet.name)} sheet selected</div>
          </div>
          <div class="sidebar-meta-card">
            <div class="sidebar-meta-label">Rows / Columns</div>
            <div class="sidebar-meta-value">${sheet.rows.length} / ${sheet.headers.length}</div>
            <div class="sidebar-meta-sub">${fillRate}% fill rate</div>
          </div>
          <div class="sidebar-meta-card">
            <div class="sidebar-meta-label">Current View</div>
            <div class="sidebar-meta-value">${state.filteredData.length || sheet.rows.length} visible rows</div>
            <div class="sidebar-meta-sub">${state.hiddenCols.size} hidden columns</div>
          </div>
        </div>
      `;
    }

    function renderSidebarSheets() {
      const container = document.getElementById('sidebar-sheet-list');
      container.innerHTML = '';
      state.sheets.forEach((sheet, i) => {
        const btn = document.createElement('button');
        btn.className = 'sidebar-sheet-btn' + (i === state.activeSheet ? ' active' : '');
        btn.dataset.sheetIndex = i;
        btn.style.borderLeftColor = PALETTE[i % PALETTE.length];
        btn.style.borderLeftWidth = i === state.activeSheet ? '3px' : '2px';
        btn.innerHTML = `<span class="sidebar-sheet-name">${escHtml(sheet.name)}</span><span class="sidebar-sheet-count">${sheet.rows.length}</span>`;
        btn.onclick = () => switchSheet(i);
        container.appendChild(btn);
      });
    }

    function renderSidebarQuickFilters() {
      const container = document.getElementById('sidebar-quick-filters');
      container.innerHTML = '';

      const statusIdx = findStatusIndex();
      const subsystemIdx = findSubsystemIndex();

      const allBtn = document.createElement('button');
      allBtn.className = 'sidebar-action-btn';
      allBtn.textContent = 'Clear Filters';
      allBtn.onclick = resetFilters;
      container.appendChild(allBtn);

      const groupBtn = document.createElement('button');
      groupBtn.className = 'sidebar-action-btn';
      groupBtn.textContent = state.groupBy === null ? 'Enable Grouping' : 'Disable Grouping';
      groupBtn.onclick = toggleGrouping;
      container.appendChild(groupBtn);

      if (statusIdx >= 0) {
        ['Required', 'Optional', 'Deprecated'].forEach(label => {
          const btn = document.createElement('button');
          btn.className = 'sidebar-action-btn';
          btn.textContent = label;
          btn.onclick = () => {
            state.colFilters[statusIdx] = label;
            state.page = 1;
            applyFilters();
            toast('Filtered status: ' + label);
          };
          container.appendChild(btn);
        });
      }

      if (subsystemIdx >= 0) {
        const topValues = getTopColumnValues(subsystemIdx, 2);
        topValues.forEach(value => {
          const btn = document.createElement('button');
          btn.className = 'sidebar-action-btn';
          btn.textContent = value;
          btn.onclick = () => {
            state.colFilters[subsystemIdx] = value;
            state.page = 1;
            applyFilters();
            toast('Filtered Sub-System: ' + value);
          };
          container.appendChild(btn);
        });
      }
    }

    function renderSidebarActiveView() {
      const container = document.getElementById('sidebar-active-filters');
      container.innerHTML = '';

      const pills = [];
      if (state.search) {
        pills.push({
          label: 'Search: ' + state.search,
          clear: () => {
            state.search = '';
            document.getElementById('search-input').value = '';
            document.getElementById('global-search-panel').classList.remove('visible');
            applyFilters();
          },
        });
      }
      if (state.groupBy !== null) {
        pills.push({
          label: 'Grouped',
          clear: () => {
            state.groupBy = null;
            state.groupCollapsed.clear();
            updateGroupButton();
            applyFilters();
          },
        });
      }
      if (state.sortCols.length) {
        pills.push({
          label: 'Sort: ' + state.sortCols.map(s => `${getActiveSheet().headers[s.col]} ${s.dir}`).join(', '),
          clear: () => {
            state.sortCols = [];
            applyFilters();
          },
        });
      }
      Object.entries(state.colFilters).forEach(([col, val]) => {
        if (!val || val === '__all__') return;
        pills.push({
          label: `${getActiveSheet().headers[col]}: ${val}`,
          clear: () => {
            delete state.colFilters[col];
            const sel = document.querySelector(`.col-filter-select[data-col="${col}"]`);
            if (sel) sel.value = '__all__';
            applyFilters();
          },
        });
      });
      if (state.hiddenCols.size) {
        pills.push({
          label: `${state.hiddenCols.size} columns hidden`,
          clear: () => {
            state.hiddenCols = new Set();
            renderColVisibility();
            applyFilters();
          },
        });
      }

      if (!pills.length) {
        container.innerHTML = '<div class="sidebar-empty">No active filters. Use search, column filters, grouping, or quick actions to narrow the table.</div>';
        return;
      }

      const row = document.createElement('div');
      row.className = 'sidebar-pill-row';
      pills.forEach(({ label, clear }) => {
        const pill = document.createElement('span');
        pill.className = 'sidebar-filter-pill';
        pill.appendChild(document.createTextNode(label));

        const close = document.createElement('button');
        close.type = 'button';
        close.setAttribute('aria-label', 'Clear ' + label);
        close.textContent = '×';
        close.onclick = (e) => {
          e.stopPropagation();
          clear();
        };
        pill.appendChild(close);
        row.appendChild(pill);
      });
      container.appendChild(row);
    }

    function getTopColumnValues(colIdx, limit) {
      const counts = {};
      getActiveSheet().rows.forEach(row => {
        const value = (row[colIdx] || '').toString().trim();
        if (!value) return;
        counts[value] = (counts[value] || 0) + 1;
      });
      return Object.entries(counts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, limit)
        .map(([value]) => value);
    }

    // ===== Stats =====
    function renderStats() {
      const sheet = getActiveSheet();
      const rows = sheet.rows;
      const accentColors = ['#3b82f6', '#10b981', '#8b5cf6', '#f59e0b'];
      const cards = [
        {
          label: 'Total Rows',
          value: rows.length,
          sub: 'data rows',
          accent: accentColors[0],
          title: 'Total number of component rows in the active profile.',
          icon: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>',
        },
        {
          label: 'Columns',
          value: sheet.headers.length,
          sub: 'fields',
          accent: accentColors[1],
          title: 'Number of available columns in the active sheet.',
          icon: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><line x1="9" y1="4" x2="9" y2="20"/><line x1="15" y1="4" x2="15" y2="20"/></svg>',
        },
        {
          label: 'Sheet',
          value: state.activeSheet + 1,
          sub: 'of ' + state.sheets.length,
          accent: accentColors[2],
          title: 'Position of the active profile within the workbook.',
          icon: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 3 7l9 5 9-5-9-5Z"/><path d="m3 12 9 5 9-5"/><path d="m3 17 9 5 9-5"/></svg>',
        },
      ];

      let filled = 0;
      let total = 0;
      rows.forEach(r => r.forEach(c => {
        total += 1;
        if (c && c.toString().trim()) filled += 1;
      }));
      cards.push({
        label: 'Fill Rate',
        value: Math.round((filled / Math.max(total, 1)) * 100) + '%',
        sub: filled + '/' + total + ' cells',
        accent: accentColors[3],
        title: 'Percentage of non-empty cells across the active sheet.',
        icon: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
      });

      const container = document.getElementById('stat-cards');
      container.innerHTML = '';
      cards.forEach(c => {
        const div = document.createElement('div');
        div.className = 'stat-card';
        div.title = c.title;
        div.style.cssText += `--card-accent: ${c.accent};`;
        div.innerHTML = `<span class="stat-icon">${c.icon}</span><div class="stat-label">${c.label}</div><div class="stat-value" style="color:${c.accent}" data-target="${c.value}">${c.value}</div><div class="stat-sub">${c.sub}</div>`;
        container.appendChild(div);
      });
      animateCounters();
    }

    function animateCounters() {
      document.querySelectorAll('.stat-value[data-target]').forEach(el => {
        const raw = el.getAttribute('data-target');
        if (raw.endsWith('%')) {
          const end = parseInt(raw, 10);
          let start = 0;
          const step = () => {
            start = Math.min(start + 3, end);
            el.textContent = start + '%';
            if (start < end) requestAnimationFrame(step);
          };
          requestAnimationFrame(step);
        } else if (!isNaN(raw)) {
          const end = parseInt(raw, 10);
          let start = 0;
          const inc = Math.max(1, Math.ceil(end / 40));
          const step = () => {
            start = Math.min(start + inc, end);
            el.textContent = start;
            if (start < end) requestAnimationFrame(step);
          };
          requestAnimationFrame(step);
        }
      });
    }

    // ===== Column Visibility =====
    function renderColVisibility() {
      const sheet = getActiveSheet();
      const panel = document.getElementById('col-vis-panel');
      panel.innerHTML = '';
      sheet.headers.forEach((h, i) => {
        const chip = document.createElement('span');
        chip.className = 'col-toggle-chip' + (state.hiddenCols.has(i) ? '' : ' active');
        chip.textContent = h.replace('\n', ' ');
        chip.onclick = () => {
          if (state.hiddenCols.has(i)) state.hiddenCols.delete(i);
          else state.hiddenCols.add(i);
          chip.classList.toggle('active');
          applyFilters();
        };
        panel.appendChild(chip);
      });
    }

    // ===== Filtering & Search =====
    function levenshtein(a, b) {
      const m = a.length;
      const n = b.length;
      if (m === 0) return n;
      if (n === 0) return m;
      const dp = Array.from({ length: m + 1 }, (_, i) =>
        Array.from({ length: n + 1 }, (_, j) => (i === 0 ? j : j === 0 ? i : 0))
      );
      for (let i = 1; i <= m; i += 1) {
        for (let j = 1; j <= n; j += 1) {
          dp[i][j] = a[i - 1] === b[j - 1]
            ? dp[i - 1][j - 1]
            : 1 + Math.min(dp[i - 1][j - 1], dp[i - 1][j], dp[i][j - 1]);
        }
      }
      return dp[m][n];
    }

    function fuzzyMatch(text, query) {
      if (!query) return true;
      text = text.toLowerCase();
      query = query.toLowerCase();
      if (text.includes(query)) return true;
      if (query.length >= 4) {
        const words = text.split(/\s+/);
        for (const w of words) {
          if (Math.abs(w.length - query.length) <= 2 && levenshtein(w.slice(0, query.length), query) <= 1) return true;
        }
      }
      return false;
    }

    function isCommonCoreHeader(header) {
      return /common[\s/_-]*core|core[\s/_-]*features|core[\s/_-]*components/i.test((header || '').toString());
    }

    // These columns are part of the hierarchical Excel grouping (a feature's Feature
    // Subset / Detailed Feature List / Component Repo only appear once, on the first
    // row of that group). Sorting by them breaks that grouping and scatters rows in
    // a way that looks "random", so header-click sorting is disabled for these.
    function isSortDisabledHeader(header) {
      return /feature[\s/_-]*subset|detailed[\s/_-]*feature[\s/_-]*list|component[\s/_-]*repo/i.test((header || '').toString());
    }

    // Sparse freeform remark columns (a blank cell here genuinely means "no note"
    // for that row, not "same note as the row above"). Forward-filling these
    // leaks one row's note across every subsequent blank row.
    function isFreeTextHeader(header) {
      return /\bstatus\b|\bnotes?\b|description|comment|dependenc/i.test((header || '').toString());
    }

    function isEthWanWifiRouterHeader(header) {
      return /ethwan|wifi.*router/i.test((header || '').toString());
    }

    function getAutoHiddenCols(sheet) {
      const hasCommonCoreFilter = Object.entries(state.colFilters).some(([col, val]) =>
        val && val !== '__all__' && isCommonCoreHeader(sheet.headers[col])
      );
      if (!hasCommonCoreFilter) return new Set();
      const autoHidden = new Set();
      sheet.headers.forEach((h, i) => {
        if (isEthWanWifiRouterHeader(h)) autoHidden.add(i);
      });
      return autoHidden;
    }

    function applyFilters() {
      const sheet = getActiveSheet();
      const filledRows = forwardFillRows(sheet.rows, sheet.headers);
      let data = filledRows.map((row, i) => ({ row, origIdx: i, displayRow: sheet.rows[i] }));

      Object.entries(state.colFilters).forEach(([col, val]) => {
        if (val && val !== '__all__') {
          const filterValue = val.trim();
          if (isCommonCoreHeader(sheet.headers[col])) {
            data = data.filter(d => {
              const rawValue = (((sheet.rows[d.origIdx] || [])[col]) || '').toString().trim();
              return rawValue === filterValue;
            });
          } else {
            data = data.filter(d => (d.row[col] || '').toString().trim() === filterValue);
          }
        }
      });

      if (state.search) {
        data = data.filter(d => d.row.some(c => fuzzyMatch((c || '').toString(), state.search)));
      }

      const activeSortCols = state.sortCols.filter(s => !isSortDisabledHeader(sheet.headers[s.col]));
      if (activeSortCols.length) {
        data.sort((a, b) => {
          for (const { col, dir } of activeSortCols) {
            const va = (a.row[col] || '').toString();
            const vb = (b.row[col] || '').toString();
            const n = va.localeCompare(vb, undefined, { numeric: true, sensitivity: 'base' });
            if (n !== 0) return dir === 'asc' ? n : -n;
          }
          return 0;
        });
      }

      state.filteredData = data.map(d => ({ row: d.displayRow, origIdx: d.origIdx }));

      const announce = document.getElementById('sr-announce');
      if (announce) announce.textContent = `${state.filteredData.length} rows found`;

      renderTable();
      renderPagination();
      renderSidebarSummary();
      renderSidebarActiveView();
      updateHash();
      updateGroupButton();
    }

    // ===== Charts =====
    function renderCharts() {
      renderDonutChart();
      renderBarChart();
    }

    function themeVar(name, fallback) {
      const value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
      return value || fallback;
    }

    function resizeCanvas(canvas) {
      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      if (w > 0 && h > 0 && (canvas.width !== w || canvas.height !== h)) {
        canvas.width = w;
        canvas.height = h;
        delete canvas._animState;
        delete canvas._animVersion;
        delete canvas._barAnim;
        delete canvas._barAnimVersion;
      }
    }

    function forwardFillRows(rows, headers) {
      const denyFill = [isCommonCoreHeader, isFreeTextHeader];
      const fillCols = headers.map((h, i) => {
        const emptyCount = rows.filter(r => !(r[i] || '').toString().trim()).length;
        const emptyRate = emptyCount / Math.max(rows.length, 1);
        const isKnown = /sub-?system|feature.?name|feature.?subset|network.?util|category/i.test(h);
        const isDenied = denyFill.some(match => match(h));
        return ((emptyRate > 0.4 || isKnown) && !isDenied) ? i : -1;
      }).filter(i => i >= 0);

      const lastSeen = {};
      return rows.map(row => {
        const newRow = [...row];
        fillCols.forEach(ci => {
          const v = (row[ci] || '').toString().trim();
          if (v) lastSeen[ci] = v;
          else if (lastSeen[ci]) newRow[ci] = lastSeen[ci];
        });
        return newRow;
      });
    }

    function renderDonutChart() {
      const canvas = document.getElementById('donut-canvas');
      if (!canvas) return;
      resizeCanvas(canvas);
      const sheet = getActiveSheet();
      const ctx = canvas.getContext('2d');
      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      const ssIdx = findSubsystemIndex(sheet);
      if (ssIdx < 0) {
        ctx.fillStyle = themeVar('--text-muted', '#64748b');
        ctx.font = '13px Inter, sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText('No Sub-System column found', 12, 28);
        return;
      }

      // Forward-fill Sub-System column
      let lastSeen = '';
      const counts = {};
      sheet.rows.forEach(r => {
        const v = (r[ssIdx] || '').toString().trim();
        if (v) lastSeen = v;
        const key = lastSeen || 'Unknown';
        counts[key] = (counts[key] || 0) + 1;
      });
      const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]);
      const total = entries.reduce((s, [, v]) => s + v, 0);
      if (!entries.length) return;

      // Dynamic layout based on canvas dimensions
      const cx = Math.round(W * 0.22);
      const cy = Math.round(H / 2);
      const R = Math.round(Math.min(cx, cy) * 0.85);
      const r = Math.round(R * 0.52);

      // Build segments
      let angle = -Math.PI / 2;

      const segments = entries.map(([label, count], i) => {
        const sweep = (count / total) * 2 * Math.PI;
        const start = angle;
        const end = angle + sweep;
        angle = end;
        return { label, count, start, end, color: PALETTE[i % PALETTE.length] };
      });

      // Animation state
      if (!canvas._animState || canvas._animVersion !== sheet.name) {
        canvas._animState = { progress: 0, hoveredIdx: -1 };
        canvas._animVersion = sheet.name;
      }
      const anim = canvas._animState;

      function ease(t) { return t < 0.5 ? 2*t*t : -1+(4-2*t)*t; }

      function draw(progress) {
        ctx.clearRect(0, 0, W, H);
        const bgCard = themeVar('--bg-card', '#fff');
        const textPrimary = themeVar('--text-primary', '#0f172a');
        const textMuted = themeVar('--text-muted', '#64748b');
        const textSec = themeVar('--text-secondary', '#475569');

        const p = Math.min(progress, 1);
        let drawnAngle = -Math.PI / 2;

        segments.forEach((s, i) => {
          const sweep = s.end - s.start;
          const visEnd = s.start + sweep * p;
          if (visEnd <= s.start) return;

          const isHovered = anim.hoveredIdx === i;
          let ox = 0, oy = 0;
          if (isHovered) {
            const mid = (s.start + visEnd) / 2;
            ox = Math.cos(mid) * 8;
            oy = Math.sin(mid) * 8;
          }

          // Gradient fill
          const midAngle = (s.start + visEnd) / 2;
          const gx1 = cx + ox + Math.cos(midAngle) * r;
          const gy1 = cy + oy + Math.sin(midAngle) * r;
          const gx2 = cx + ox + Math.cos(midAngle) * R;
          const gy2 = cy + oy + Math.sin(midAngle) * R;
          const grad = ctx.createLinearGradient(gx1, gy1, gx2, gy2);
          const baseColor = s.color;
          grad.addColorStop(0, baseColor + 'cc');
          grad.addColorStop(1, baseColor);

          ctx.beginPath();
          ctx.moveTo(cx + ox, cy + oy);
          ctx.arc(cx + ox, cy + oy, R, s.start, visEnd);
          ctx.closePath();
          ctx.fillStyle = grad;
          ctx.fill();
          ctx.strokeStyle = bgCard;
          ctx.lineWidth = isHovered ? 3 : 2;
          ctx.stroke();
        });

        // Center hole
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, 2 * Math.PI);
        ctx.fillStyle = bgCard;
        ctx.fill();

        // Center text
        ctx.textAlign = 'center';
        if (anim.hoveredIdx >= 0 && anim.hoveredIdx < segments.length) {
          const hs = segments[anim.hoveredIdx];
          const pct = Math.round((hs.count / total) * 100);
          ctx.fillStyle = hs.color;
          ctx.font = 'bold 20px Inter, sans-serif';
          ctx.fillText(hs.count, cx, cy - 4);
          ctx.fillStyle = textMuted;
          ctx.font = '10px Inter, sans-serif';
          const short = hs.label.length > 14 ? hs.label.slice(0, 13) + '…' : hs.label;
          ctx.fillText(short, cx, cy + 11);
          ctx.fillText(pct + '%', cx, cy + 24);
        } else {
          ctx.fillStyle = textPrimary;
          ctx.font = 'bold 22px Inter, sans-serif';
          ctx.fillText(total, cx, cy + 6);
          ctx.fillStyle = textMuted;
          ctx.font = '11px Inter, sans-serif';
          ctx.fillText('total', cx, cy + 22);
        }

        // Legend (right side)
        const legendX = cx * 2 + R + 20;
        const legendStartY = 18;
        const rowH = 26;
        const swatchSize = 12;
        const colGap = 8;
        const countColX = W - 6;
        ctx.font = '11px Inter, sans-serif';
        ctx.textAlign = 'left';

        let maxLabelW = 0;
        entries.forEach(([label]) => {
          const short = label.length > 16 ? label.slice(0, 15) + '…' : label;
          maxLabelW = Math.max(maxLabelW, ctx.measureText(short).width);
        });

        entries.forEach(([label, count], i) => {
          const y = legendStartY + i * rowH;
          if (y + rowH > H) return;
          const isHov = anim.hoveredIdx === i;
          const short = label.length > 16 ? label.slice(0, 15) + '…' : label;
          const pct = Math.round((count / total) * 100);
          const labelX = legendX + swatchSize + colGap;
          const barX = labelX + maxLabelW + 6;
          const barAvailW = countColX - barX - 62;
          const barW = Math.max(0, barAvailW);
          const fillW = barW > 8 ? Math.round(barW * count / total) : 0;

          ctx.fillStyle = PALETTE[i % PALETTE.length];
          if (typeof ctx.roundRect === 'function') {
            ctx.beginPath();
            ctx.roundRect(legendX, y - swatchSize + 2, swatchSize, swatchSize, 2);
            ctx.fill();
          } else {
            ctx.fillRect(legendX, y - swatchSize + 2, swatchSize, swatchSize);
          }

          ctx.fillStyle = isHov ? PALETTE[i % PALETTE.length] : textSec;
          ctx.font = isHov ? 'bold 11px Inter, sans-serif' : '11px Inter, sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText(short, labelX, y);

          if (barW >= 20) {
            ctx.fillStyle = themeVar('--border', '#e5e7eb');
            ctx.fillRect(barX, y + 4, barW, 3);
            ctx.fillStyle = PALETTE[i % PALETTE.length];
            ctx.fillRect(barX, y + 4, fillW, 3);
          }

          ctx.fillStyle = textMuted;
          ctx.font = '11px Inter, sans-serif';
          ctx.textAlign = 'right';
          ctx.fillText(`${count} (${pct}%)`, countColX, y);
        });
      }

      // Animate
      if (anim.progress < 1) {
        let start = null;
        function animate(ts) {
          if (!start) start = ts;
          const elapsed = ts - start;
          anim.progress = Math.min(elapsed / 700, 1);
          draw(ease(anim.progress));
          if (anim.progress < 1) requestAnimationFrame(animate);
        }
        requestAnimationFrame(animate);
      } else {
        draw(1);
      }

      // Hover
      canvas.onmousemove = (e) => {
        const rect = canvas.getBoundingClientRect();
        const scaleX = canvas.width / rect.width;
        const scaleY = canvas.height / rect.height;
        const x = (e.clientX - rect.left) * scaleX;
        const y = (e.clientY - rect.top) * scaleY;
        const mx = x - cx, my = y - cy;
        const dist = Math.sqrt(mx * mx + my * my);
        let hovered = -1;
        if (dist >= r && dist <= R) {
          let a = Math.atan2(my, mx);
          if (a < -Math.PI / 2) a += 2 * Math.PI;
          hovered = segments.findIndex(sg => a >= sg.start && a <= sg.end);
        }
        if (hovered !== anim.hoveredIdx) {
          anim.hoveredIdx = hovered;
          canvas.style.cursor = hovered >= 0 ? 'pointer' : 'default';
          draw(1);
        }
      };

      canvas.onmouseleave = () => {
        if (anim.hoveredIdx !== -1) {
          anim.hoveredIdx = -1;
          canvas.style.cursor = 'default';
          draw(1);
        }
      };

      // Store segments for click
      canvas._segments = segments.map(s => ({ ...s, cx, cy, R, r, colIdx: ssIdx }));

      canvas.onclick = (e) => {
        const rect = canvas.getBoundingClientRect();
        const scaleX = canvas.width / rect.width;
        const scaleY = canvas.height / rect.height;
        const x = (e.clientX - rect.left) * scaleX;
        const y = (e.clientY - rect.top) * scaleY;
        const mx = x - cx, my = y - cy;
        const dist = Math.sqrt(mx * mx + my * my);
        if (dist <= r || dist >= R) return;

        let a = Math.atan2(my, mx);
        if (a < -Math.PI / 2) a += 2 * Math.PI;
        const seg = canvas._segments.find(sg => a >= sg.start && a <= sg.end);
        if (!seg) return;

        state.colFilters[seg.colIdx] = state.colFilters[seg.colIdx] === seg.label ? '__all__' : seg.label;
        const sel = document.querySelector(`.col-filter-select[data-col="${seg.colIdx}"]`);
        if (sel) sel.value = state.colFilters[seg.colIdx] || '__all__';
        state.page = 1;
        applyFilters();
        toast(`Filtered: ${seg.label}`);
      };
    }

    function renderBarChart() {
      const canvas = document.getElementById('bar-canvas');
      if (!canvas) return;
      resizeCanvas(canvas);
      const ctx = canvas.getContext('2d');
      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      const data = state.sheets.map((s, i) => ({
        name: s.name,
        count: s.rows.length,
        color: PALETTE[i % PALETTE.length],
        isActive: i === state.activeSheet,
      }));
      const maxVal = Math.max(...data.map(d => d.count), 1);
      const barH = Math.min(28, Math.floor((H - 20) / data.length) - 6);
      const gap = Math.min(8, Math.floor((H - 20 - data.length * barH) / Math.max(data.length - 1, 1)));
      const padL = 90;
      const padR = 44;
      const padT = 14;

      // Grid lines
      const textMuted = themeVar('--text-muted', '#64748b');
      const gridColor = themeVar('--border', '#e5e7eb');
      const gridSteps = 4;
      for (let g = 0; g <= gridSteps; g++) {
        const gx = padL + Math.round((g / gridSteps) * (W - padL - padR));
        ctx.beginPath();
        ctx.moveTo(gx, padT - 6);
        ctx.lineTo(gx, padT + data.length * (barH + gap));
        ctx.strokeStyle = gridColor;
        ctx.lineWidth = 1;
        ctx.stroke();
        if (g > 0) {
          ctx.fillStyle = textMuted;
          ctx.font = '9px Inter, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(Math.round((g / gridSteps) * maxVal), gx, padT - 2);
        }
      }

      // Animation
      if (!canvas._barAnim || canvas._barAnimVersion !== state.sheets.map(s=>s.name).join(',')) {
        canvas._barAnim = { progress: 0 };
        canvas._barAnimVersion = state.sheets.map(s=>s.name).join(',');
      }
      const barAnim = canvas._barAnim;

      function ease(t) { return t < 0.5 ? 2*t*t : -1+(4-2*t)*t; }

      function drawBars(progress) {
        ctx.clearRect(0, 0, W, H);
        // redraw grid
        for (let g = 0; g <= gridSteps; g++) {
          const gx = padL + Math.round((g / gridSteps) * (W - padL - padR));
          ctx.beginPath();
          ctx.moveTo(gx, padT - 6);
          ctx.lineTo(gx, padT + data.length * (barH + gap));
          ctx.strokeStyle = gridColor;
          ctx.lineWidth = 1;
          ctx.stroke();
          if (g > 0) {
            ctx.fillStyle = textMuted;
            ctx.font = '9px Inter, sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(Math.round((g / gridSteps) * maxVal), gx, padT - 2);
          }
        }

        data.forEach(({ name, count, color, isActive }, i) => {
          const y = padT + i * (barH + gap);
          const fullW = Math.max(2, Math.round((count / maxVal) * (W - padL - padR)));
          const bw = Math.round(fullW * progress);

          // Gradient bar
          const grad = ctx.createLinearGradient(padL, y, padL + bw, y);
          grad.addColorStop(0, color + '99');
          grad.addColorStop(1, color);
          ctx.fillStyle = grad;
          if (typeof ctx.roundRect === 'function') {
            ctx.beginPath();
            ctx.roundRect(padL, y, bw, barH, 4);
            ctx.fill();
          } else {
            ctx.fillRect(padL, y, bw, barH);
          }

          // Active sheet highlight
          if (isActive) {
            ctx.strokeStyle = color;
            ctx.lineWidth = 1.5;
            if (typeof ctx.roundRect === 'function') {
              ctx.beginPath();
              ctx.roundRect(padL, y, W - padL - padR, barH, 4);
              ctx.stroke();
            }
          }

          // Label (left)
          const textSec = themeVar('--text-secondary', '#475569');
          const textPrim = themeVar('--text-primary', '#0f172a');
          ctx.fillStyle = isActive ? color : textSec;
          ctx.font = isActive ? 'bold 11px Inter, sans-serif' : '11px Inter, sans-serif';
          ctx.textAlign = 'right';
          const short = name.length > 12 ? name.slice(0, 11) + '…' : name;
          ctx.fillText(short, padL - 6, y + barH / 2 + 4);

          // Count (right)
          if (progress > 0.5) {
            ctx.fillStyle = textPrim;
            ctx.textAlign = 'left';
            ctx.font = 'bold 10px Inter, sans-serif';
            ctx.fillText(count, Math.min(padL + bw + 5, W - padR + 2), y + barH / 2 + 4);
          }
        });
      }

      if (barAnim.progress < 1) {
        let start = null;
        function animate(ts) {
          if (!start) start = ts;
          const elapsed = ts - start;
          barAnim.progress = Math.min(elapsed / 600, 1);
          drawBars(ease(barAnim.progress));
          if (barAnim.progress < 1) requestAnimationFrame(animate);
        }
        requestAnimationFrame(animate);
      } else {
        drawBars(1);
      }

      // Hover
      canvas.onmousemove = (e) => {
        const rect = canvas.getBoundingClientRect();
        const scaleY = canvas.height / rect.height;
        const y = (e.clientY - rect.top) * scaleY;
        let found = -1;
        data.forEach((_, i) => {
          const by = padT + i * (barH + gap);
          if (y >= by && y <= by + barH) found = i;
        });
        canvas.style.cursor = found >= 0 ? 'pointer' : 'default';
      };

      canvas.onclick = (e) => {
        const rect = canvas.getBoundingClientRect();
        const scaleY = canvas.height / rect.height;
        const y = (e.clientY - rect.top) * scaleY;
        data.forEach((d, i) => {
          const by = padT + i * (barH + gap);
          if (y >= by && y <= by + barH) {
            switchSheet(i);
          }
        });
      };
    }

    // ===== Table Rendering =====
    function renderTable() {
      const sheet = getActiveSheet();
      const headers = sheet.headers;
      const table = document.getElementById('data-table');
      const autoHiddenCols = getAutoHiddenCols(sheet);
      const visHeaders = headers.map((h, i) => ({ h, i })).filter(x => !state.hiddenCols.has(x.i) && !autoHiddenCols.has(x.i));
      const thead = table.querySelector('thead');
      const tbody = table.querySelector('tbody');
      thead.innerHTML = '';
      tbody.innerHTML = '';

      const hmRow = document.createElement('tr');
      hmRow.className = 'heatmap-row';
      const hmCb = document.createElement('th');
      hmCb.style.background = 'var(--bg-secondary)';
      hmRow.appendChild(hmCb);

      visHeaders.forEach(({ h, i }) => {
        const th = document.createElement('th');
        const col = sheet.rows.map(r => r[i] || '');
        const pct = Math.round(col.filter(v => v.toString().trim()).length / Math.max(col.length, 1) * 100);
        const color = pct >= 80 ? `rgba(16,185,129,${0.15 + pct / 200})`
          : pct >= 50 ? `rgba(245,158,11,${0.1 + pct / 400})`
          : `rgba(239,68,68,0.12)`;
        th.style.cssText = `background: ${color} !important; color: var(--text-secondary) !important;`;
        th.textContent = pct + '%';
        th.title = h.replace('\n', ' ') + ': ' + pct + '% filled';
        hmRow.appendChild(th);
      });
      thead.appendChild(hmRow);

      const headerRow = document.createElement('tr');
      const cbTh = document.createElement('th');
      cbTh.style.width = '36px';
      headerRow.appendChild(cbTh);

      visHeaders.forEach(({ h, i }) => {
        const th = document.createElement('th');
        th.style.position = 'relative';
        if (state.colWidths[i]) {
          th.style.width = state.colWidths[i] + 'px';
          th.style.minWidth = state.colWidths[i] + 'px';
        }

        const sortDisabled = isSortDisabledHeader(h);
        if (sortDisabled) {
          th.style.cursor = 'default';
          th.title = 'Sorting is disabled for this column to preserve feature grouping';
        }

        const sortInfo = sortDisabled ? undefined : state.sortCols.find(s => s.col === i);
        const sortPriority = state.sortCols.findIndex(s => s.col === i) + 1;

        const label = document.createElement('span');
        label.textContent = h.replace('\n', ' ');
        th.appendChild(label);

        if (sortInfo) {
          const badge = document.createElement('span');
          badge.className = 'sort-badge';
          badge.textContent = sortPriority;
          th.appendChild(badge);

          const arrow = document.createElement('span');
          arrow.className = 'sort-arrow';
          arrow.textContent = sortInfo.dir === 'asc' ? '↑' : '↓';
          th.appendChild(arrow);
        }

        th.onclick = (e) => {
          if (sortDisabled) return;
          if (e.target.closest('select') || e.target.closest('.col-resize')) return;
          if (e.shiftKey) {
            const existing = state.sortCols.find(s => s.col === i);
            if (existing) existing.dir = existing.dir === 'asc' ? 'desc' : 'asc';
            else state.sortCols.push({ col: i, dir: 'asc' });
          } else {
            const existing = state.sortCols.find(s => s.col === i);
            if (existing && state.sortCols.length === 1) existing.dir = existing.dir === 'asc' ? 'desc' : 'asc';
            else state.sortCols = [{ col: i, dir: 'asc' }];
          }
          applyFilters();
        };


        const filledRowsForDropdown = forwardFillRows(sheet.rows, sheet.headers);
        const vals = [...new Set(filledRowsForDropdown.map(r => (r[i] || '').toString()).filter(v => v.trim()))].sort((a, b) =>
          a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })
        );
        if (vals.length < 50 && vals.length > 0) {
          const sel = document.createElement('select');
          sel.className = 'col-filter-select';
          sel.dataset.col = i;
          const allOpt = document.createElement('option');
          allOpt.value = '__all__';
          allOpt.textContent = 'All';
          sel.appendChild(allOpt);
          vals.forEach(v => {
            const opt = document.createElement('option');
            opt.value = v;
            opt.textContent = v.length > 30 ? v.slice(0, 29) + '…' : v;
            sel.appendChild(opt);
          });
          sel.value = state.colFilters[i] || '__all__';
          sel.onclick = e => e.stopPropagation();
          sel.onchange = (e) => {
            state.colFilters[i] = e.target.value;
            state.page = 1;
            applyFilters();
          };
          th.appendChild(sel);
        }

        const rh = document.createElement('div');
        rh.className = 'col-resize';
        let startX;
        let startW;
        rh.addEventListener('mousedown', (e) => {
          e.preventDefault();
          e.stopPropagation();
          startX = e.clientX;
          startW = th.offsetWidth;
          rh.classList.add('active');
          const onMove = (ev) => {
            const w = Math.max(60, startW + ev.clientX - startX);
            state.colWidths[i] = w;
            th.style.minWidth = w + 'px';
            th.style.width = w + 'px';
          };
          const onUp = () => {
            rh.classList.remove('active');
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
          };
          document.addEventListener('mousemove', onMove);
          document.addEventListener('mouseup', onUp);
        });
        th.appendChild(rh);
        headerRow.appendChild(th);
      });
      thead.appendChild(headerRow);

      const totalPages = Math.max(1, Math.ceil(state.filteredData.length / state.pageSize));
      if (state.page > totalPages) state.page = totalPages;

      const start = (state.page - 1) * state.pageSize;
      const end = start + state.pageSize;
      const pageData = state.filteredData.slice(start, end);
      const filledForDisplay = forwardFillRows(sheet.rows, sheet.headers);

      const shouldGroup = state.groupBy !== null && !state.search && !Object.values(state.colFilters).some(v => v && v !== '__all__');
      if (shouldGroup) {
        const groups = {};
        pageData.forEach(d => {
          const key = (d.row[state.groupBy] || 'Unknown').toString();
          if (!groups[key]) groups[key] = [];
          groups[key].push(d);
        });

        Object.entries(groups).forEach(([key, rows]) => {
          const collapsed = state.groupCollapsed.has(key);
          const gr = document.createElement('tr');
          gr.className = 'group-row' + (collapsed ? ' collapsed' : '');
          const td = document.createElement('td');
          td.colSpan = visHeaders.length + 1;
          td.innerHTML = `<span class="group-chevron">▾</span> ${escHtml(key)} <span class="group-badge">${rows.length}</span>`;
          gr.appendChild(td);
          gr.onclick = () => {
            if (collapsed) state.groupCollapsed.delete(key);
            else state.groupCollapsed.add(key);
            renderTable();
          };
          tbody.appendChild(gr);

          if (!collapsed) rows.forEach(d => tbody.appendChild(buildRow({ row: filledForDisplay[d.origIdx], origIdx: d.origIdx }, visHeaders)));
        });
      } else {
        pageData.forEach(d => tbody.appendChild(buildRow({ row: filledForDisplay[d.origIdx], origIdx: d.origIdx }, visHeaders)));
      }

      if (!pageData.length) {
        const tr = document.createElement('tr');
        tr.id = 'empty-row';
        const td = document.createElement('td');
        td.colSpan = visHeaders.length + 1;
        td.style.cssText = 'padding:48px 24px;text-align:center';
        td.innerHTML = `<svg width="80" height="80" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 7.5A2.5 2.5 0 0 1 6.5 5h11A2.5 2.5 0 0 1 20 7.5v9a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 16.5v-9Z" stroke="currentColor" stroke-width="1.5"/><path d="M8 9h8M8 12h5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="17.5" cy="17.5" r="3.5" fill="rgba(59,130,246,0.12)" stroke="currentColor" stroke-width="1.5"/><path d="m16.3 16.3 2.4 2.4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg><div style="font-size:1.1rem;font-weight:600;color:var(--text-primary);margin:12px 0 4px">No matching components</div><div style="font-size:0.875rem;color:var(--text-muted)">Try adjusting your search or clearing active filters</div><button onclick="resetFilters()" style="margin-top:12px;padding:8px 20px;background:var(--brand-primary);color:#fff;border:none;border-radius:var(--radius-full);cursor:pointer;font-size:0.85rem">Clear Filters</button>`;
        tr.appendChild(td);
        tbody.appendChild(tr);
      }
    }

    function buildRow(d, visHeaders) {
      const tr = document.createElement('tr');
      tr.dataset.origIdx = d.origIdx;
      tr.tabIndex = 0;

      const cbTd = document.createElement('td');
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.className = 'row-compare-cb';
      cb.checked = state.compareRows.has(d.origIdx);
      cb.setAttribute('aria-label', 'Select row for comparison');
      cb.onchange = () => {
        if (cb.checked) state.compareRows.add(d.origIdx);
        else state.compareRows.delete(d.origIdx);
        updateCompareFab();
      };
      cbTd.appendChild(cb);
      tr.appendChild(cbTd);

      visHeaders.forEach(({ h, i }) => {
        const td = document.createElement('td');
        const val = (d.row[i] || '').toString();

        if (val.startsWith('http')) {
          const a = document.createElement('a');
          a.className = 'cell-link';
          a.href = val;
          a.target = '_blank';
          a.rel = 'noopener';
          a.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg> Link';
          td.appendChild(a);
        } else if (h.toLowerCase().includes('status') && val && val.length <= 20) {
          const badge = document.createElement('span');
          const icons = { required: '✓', optional: '○', deprecated: '⊘' };
          const lower = val.toLowerCase();
          const cls = lower.includes('required') ? 'status-required'
            : lower.includes('optional') ? 'status-optional'
            : lower.includes('deprecat') ? 'status-deprecated' : '';
          badge.className = cls ? `status-badge ${cls}` : 'status-badge';
          const iconKey = lower.includes('required') ? 'required' : lower.includes('optional') ? 'optional' : lower.includes('deprecat') ? 'deprecated' : null;
          badge.innerHTML = iconKey ? `<span style="margin-right:3px">${icons[iconKey]}</span>${escHtml(val)}` : escHtml(val);
          td.appendChild(badge);
        } else if (val.length > 80) {
          const span = document.createElement('span');
          span.className = 'cell-text';
          if (state.search && val.toLowerCase().includes(state.search.toLowerCase())) {
            const re = new RegExp('(' + escRegex(state.search) + ')', 'gi');
            span.innerHTML = escHtml(val).replace(re, '<mark>$1</mark>');
          } else {
            span.textContent = val;
          }
          const btn = document.createElement('span');
          btn.className = 'cell-expand-btn';
          btn.textContent = '⊞';
          btn.onclick = (e) => showCellPopover(e, val);
          td.appendChild(span);
          td.appendChild(document.createTextNode(' '));
          td.appendChild(btn);
        } else {
          if (state.search && val.toLowerCase().includes(state.search.toLowerCase())) {
            const span = document.createElement('span');
            span.className = 'cell-text';
            const re = new RegExp('(' + escRegex(state.search) + ')', 'gi');
            span.innerHTML = escHtml(val).replace(re, '<mark>$1</mark>');
            td.appendChild(span);
          } else {
            td.textContent = val;
          }
        }
        tr.appendChild(td);
      });

      return tr;
    }

    // ===== Cell Popover =====
    function showCellPopover(e, text) {
      e.stopPropagation();
      const pop = document.getElementById('cell-popover');
      pop.querySelector('#cell-popover-text').textContent = text;
      pop.classList.add('visible');
      let x = e.clientX + 10;
      let y = e.clientY + 10;
      if (x + 380 > window.innerWidth) x = e.clientX - 380;
      if (y + 200 > window.innerHeight) y = e.clientY - 200;
      pop.style.left = x + 'px';
      pop.style.top = y + 'px';
    }

    document.addEventListener('click', (e) => {
      const pop = document.getElementById('cell-popover');
      if (pop && !pop.contains(e.target)) pop.classList.remove('visible');
    });

    // ===== Pagination =====
    function renderPagination() {
      const total = state.filteredData.length;
      const pages = Math.max(1, Math.ceil(total / state.pageSize));
      if (state.page > pages) state.page = pages;
      const container = document.getElementById('pagination');
      container.innerHTML = '';

      const info = document.createElement('span');
      info.style.cssText = 'font-size:0.8rem;color:var(--text-muted);margin-right:auto';
      const start = total ? (state.page - 1) * state.pageSize + 1 : 0;
      const end = Math.min(state.page * state.pageSize, total);
      info.textContent = total > 0 ? `${start}–${end} of ${total}` : '0 results';
      container.appendChild(info);

      const sel = document.createElement('select');
      sel.id = 'rows-per-page';
      [10, 25, 50, 100, 250].forEach(n => {
        const o = document.createElement('option');
        o.value = n;
        o.textContent = n + ' / page';
        if (n === state.pageSize) o.selected = true;
        sel.appendChild(o);
      });
      sel.onchange = (e) => {
        state.pageSize = +e.target.value;
        state.page = 1;
        applyFilters();
      };
      container.appendChild(sel);

      if (pages <= 1) return;

      const prev = document.createElement('button');
      prev.className = 'page-btn';
      prev.textContent = '←';
      prev.disabled = state.page === 1;
      prev.onclick = () => {
        state.page -= 1;
        applyFilters();
      };
      container.appendChild(prev);

      pageRange(state.page, pages).forEach(p => {
        if (p === '…') {
          const span = document.createElement('span');
          span.textContent = '…';
          span.style.padding = '0 4px';
          container.appendChild(span);
          return;
        }
        const btn = document.createElement('button');
        btn.className = 'page-btn' + (p === state.page ? ' active' : '');
        btn.textContent = p;
        btn.onclick = () => {
          state.page = p;
          applyFilters();
        };
        container.appendChild(btn);
      });

      const next = document.createElement('button');
      next.className = 'page-btn';
      next.textContent = '→';
      next.disabled = state.page === pages;
      next.onclick = () => {
        state.page += 1;
        applyFilters();
      };
      container.appendChild(next);
    }

    function pageRange(cur, total) {
      if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
      const r = [1];
      if (cur > 3) r.push('…');
      for (let p = Math.max(2, cur - 1); p <= Math.min(total - 1, cur + 1); p += 1) r.push(p);
      if (cur < total - 2) r.push('…');
      r.push(total);
      return r;
    }

    // ===== Compare =====
    function updateCompareFab() {
      const fab = document.getElementById('compare-fab');
      if (state.compareRows.size >= 2) {
        fab.style.display = 'flex';
        fab.querySelector('.compare-count').textContent = state.compareRows.size;
      } else {
        fab.style.display = 'none';
      }
    }

    function openComparePanel() {
      const sheet = getActiveSheet();
      const panel = document.getElementById('compare-panel');
      const body = document.getElementById('compare-body');
      const rows = [...state.compareRows].map(i => sheet.rows[i]).filter(Boolean);
      if (rows.length < 2) {
        toast('Select at least two rows to compare');
        return;
      }

      const differingCols = new Set();
      sheet.headers.forEach((_, hi) => {
        const values = rows.map(r => (r[hi] || '').toString());
        if (values.some(v => v !== values[0])) differingCols.add(hi);
      });

      let html = '<div class="compare-grid" style="grid-template-columns:' + rows.map(() => '1fr').join(' ') + ';">';
      rows.forEach((r, ri) => {
        html += `<div class="compare-col"><div class="sidebar-meta-card" style="margin-bottom:12px"><div class="sidebar-meta-label">Row</div><div class="sidebar-meta-value">${ri + 1}</div></div>`;
        sheet.headers.forEach((h, hi) => {
          const val = escHtml((r[hi] || '').toString());
          const klass = differingCols.has(hi) ? 'compare-value compare-diff' : 'compare-value';
          html += `<div class="compare-field"><strong>${escHtml(h.replace('\n', ' '))}</strong><div class="${klass}">${val || '—'}</div></div>`;
        });
        html += '</div>';
      });
      html += '</div>';
      body.innerHTML = html;
      panel.classList.add('open');
    }

    // ===== Search =====
    function handleSearch(val) {
      state.search = val.trim();
      state.page = 1;

      if (state.search) {
        addSearchHistory(state.search);
        renderGlobalSearch(state.search);
      } else {
        document.getElementById('global-search-panel').classList.remove('visible');
      }

      applyFilters();
    }

    function addSearchHistory(q) {
      state.searchHistory = [q, ...state.searchHistory.filter(h => h !== q)].slice(0, 5);
      localStorage.setItem('searchHistory', JSON.stringify(state.searchHistory));
      renderSearchHistory();
    }

    function renderSearchHistory() {
      const container = document.getElementById('search-history');
      container.innerHTML = '';
      state.searchHistory.forEach(q => {
        const chip = document.createElement('span');
        chip.className = 'history-chip';
        chip.textContent = q;
        chip.onclick = () => {
          document.getElementById('search-input').value = q;
          handleSearch(q);
        };
        container.appendChild(chip);
      });
    }

    function renderGlobalSearch(q) {
      const panel = document.getElementById('global-search-panel');
      panel.innerHTML = '';
      let hasResults = false;

      state.sheets.forEach((sheet, si) => {
        const matches = sheet.rows
          .map((r, ri) => ({ row: r, ri }))
          .filter(({ row }) => row.some(c => fuzzyMatch((c || '').toString(), q)));
        if (!matches.length) return;
        hasResults = true;

        const group = document.createElement('div');
        group.className = 'global-sheet-group';
        group.innerHTML = `<div class="global-sheet-label">${escHtml(sheet.name)} <span class="global-badge">${matches.length}</span></div>`;

        matches.slice(0, 5).forEach(({ row, ri }) => {
          const matchCell = row.find(c => fuzzyMatch((c || '').toString(), q));
          const div = document.createElement('div');
          div.className = 'global-result-row';
          div.textContent = `Row ${ri + 1}: ${(matchCell || '').toString().slice(0, 80)}`;
          div.onclick = () => switchSheet(si);
          group.appendChild(div);
        });

        if (matches.length > 5) {
          const more = document.createElement('div');
          more.style.cssText = 'font-size:0.75rem;color:var(--text-muted);cursor:pointer';
          more.textContent = `+${matches.length - 5} more…`;
          more.onclick = () => switchSheet(si);
          group.appendChild(more);
        }
        panel.appendChild(group);
      });

      panel.classList.toggle('visible', hasResults);
    }

    // ===== Command Palette =====
    function getCommandActions() {
      const sheetActions = state.sheets.map((s, i) => ({
        icon: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>',
        name: s.name + ' Sheet',
        desc: `${s.rows.length} rows · ${s.headers.length} columns`,
        action: () => switchSheet(i),
      }));

      const actionItems = [
        { icon: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>', name: 'Export CSV', desc: 'Download filtered data as CSV', action: exportCSV },
        { icon: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>', name: 'Export JSON', desc: 'Download workbook as JSON', action: exportJSON },
        { icon: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>', name: 'Copy URL', desc: 'Copy shareable link', action: copyURL },
        { icon: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>', name: 'Print View', desc: 'Open print dialog', action: () => window.print() },
        { icon: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>', name: 'Toggle Dark Mode', desc: 'Switch light/dark theme', action: toggleTheme },
        { icon: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>', name: 'Reset Filters', desc: 'Clear all filters', action: resetFilters },
        { icon: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>', name: 'Toggle Columns', desc: 'Jump to column visibility panel', action: () => document.getElementById('col-vis-panel').scrollIntoView({ behavior: 'smooth' }) },
        { icon: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>', name: 'Toggle Grouping', desc: 'Group or ungroup rows by Sub-System', action: toggleGrouping },
      ];

      return { sheetActions, actionItems };
    }

    function openCmdPalette() {
      document.getElementById('cmd-overlay').classList.add('open');
      document.getElementById('cmd-input').value = '';
      renderCmdResults();
      setTimeout(() => document.getElementById('cmd-input').focus(), 50);
    }

    function closeCmdPalette() {
      document.getElementById('cmd-overlay').classList.remove('open');
    }

    function renderCmdResults(q = '') {
      const container = document.getElementById('cmd-results');
      container.innerHTML = '';

      const { sheetActions, actionItems } = getCommandActions();
      const filteredSheets = q ? sheetActions.filter(a => fuzzyMatch(a.name, q) || fuzzyMatch(a.desc, q)) : sheetActions;
      const filteredActions = q ? actionItems.filter(a => fuzzyMatch(a.name, q) || fuzzyMatch(a.desc, q)) : actionItems;

      if (filteredSheets.length) {
        const label = document.createElement('div');
        label.className = 'cmd-group-label';
        label.textContent = 'Sheets';
        container.appendChild(label);
        filteredSheets.forEach(a => container.appendChild(buildCmdItem(a)));
      }

      if (filteredActions.length) {
        const label = document.createElement('div');
        label.className = 'cmd-group-label';
        label.textContent = 'Actions';
        container.appendChild(label);
        filteredActions.forEach(a => container.appendChild(buildCmdItem(a)));
      }

      cmdItems = [...filteredSheets, ...filteredActions];
      cmdSelected = 0;
      const items = container.querySelectorAll('.cmd-item');
      items.forEach((el, i) => el.classList.toggle('selected', i === 0));
    }

    function buildCmdItem(action) {
      const div = document.createElement('div');
      div.className = 'cmd-item';
      div.innerHTML = `<div class="cmd-icon">${action.icon}</div><div><div class="cmd-name">${escHtml(action.name)}</div><div class="cmd-desc">${escHtml(action.desc)}</div></div>`;
      div.onclick = () => {
        action.action();
        closeCmdPalette();
      };
      return div;
    }

    // ===== Export =====
    function exportCSV() {
      const sheet = getActiveSheet();
      const autoHiddenCols = getAutoHiddenCols(sheet);
      const visHeaders = sheet.headers.filter((_, i) => !state.hiddenCols.has(i) && !autoHiddenCols.has(i));
      const visIdxs = sheet.headers.map((_, i) => i).filter(i => !state.hiddenCols.has(i) && !autoHiddenCols.has(i));
      const rows = [visHeaders, ...state.filteredData.map(d => visIdxs.map(i => d.row[i] || ''))];
      const csv = rows.map(r => r.map(c => '"' + c.toString().replace(/"/g, '""') + '"').join(',')).join('\n');
      download('export.csv', csv, 'text/csv');
      toast(`CSV exported — ${state.filteredData.length} rows`);
    }

    function exportJSON() {
      const el = document.getElementById('workbook' + '-data');
      download('workbook.json', el.textContent, 'application/json');
      toast('JSON exported');
    }

    function copyURL() {
      updateHash();
      copyText(location.href)
        .then(() => toast('🔗 URL copied!'))
        .catch(() => toast('Unable to copy URL'));
    }

    function download(name, data, type) {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([data], { type }));
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    }

    function resetFilters() {
      state.colFilters = {};
      state.search = '';
      state.sortCols = [];
      state.page = 1;
      state.groupBy = null;
      state.groupCollapsed.clear();
      state.hiddenCols = new Set();
      document.getElementById('search-input').value = '';
      document.getElementById('global-search-panel').classList.remove('visible');
      renderColVisibility();
      updateGroupButton();
      applyFilters();
      toast('Filters cleared');
    }

    function toggleGrouping() {
      const subsystemIdx = findSubsystemIndex();
      if (subsystemIdx < 0) {
        toast('No Sub-System column available for grouping');
        return;
      }
      state.groupBy = state.groupBy === null ? subsystemIdx : null;
      state.groupCollapsed.clear();
      updateGroupButton();
      applyFilters();
      toast(state.groupBy === null ? 'Grouping disabled' : 'Grouping enabled');
    }

    function updateGroupButton() {
      const btn = document.getElementById('group-toggle-btn');
      if (!btn) return;
      btn.textContent = state.groupBy === null ? '⊞ Group' : '⊟ Ungroup';
      btn.setAttribute('aria-pressed', String(state.groupBy !== null));
    }

    function copyText(text) {
      if (navigator.clipboard && window.isSecureContext) {
        return navigator.clipboard.writeText(text);
      }
      return new Promise((resolve, reject) => {
        const input = document.createElement('textarea');
        input.value = text;
        input.style.position = 'fixed';
        input.style.opacity = '0';
        document.body.appendChild(input);
        input.focus();
        input.select();
        try {
          const ok = document.execCommand('copy');
          input.remove();
          ok ? resolve() : reject(new Error('copy failed'));
        } catch (err) {
          input.remove();
          reject(err);
        }
      });
    }

    // ===== Nav bindings =====
    function bindNav() {
      document.getElementById('dark-toggle').onclick = toggleTheme;
      document.getElementById('cmd-btn').onclick = openCmdPalette;
      document.getElementById('export-csv-btn').onclick = exportCSV;
      document.getElementById('export-json-btn').onclick = exportJSON;
      document.getElementById('copy-url-btn').onclick = copyURL;
      document.getElementById('print-btn').onclick = () => window.print();
      document.getElementById('group-toggle-btn').onclick = toggleGrouping;
      bindWorkbookLoader();

      const searchInput = document.getElementById('search-input');
      let searchTimeout;
      searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => handleSearch(e.target.value), 250);
      });

      document.getElementById('reset-filters-btn').onclick = resetFilters;
      document.getElementById('compare-fab').onclick = openComparePanel;
      document.getElementById('compare-fab').onkeydown = (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openComparePanel();
        }
      };
      document.getElementById('compare-close').onclick = () => document.getElementById('compare-panel').classList.remove('open');
      document.getElementById('cell-popover-close').onclick = () => document.getElementById('cell-popover').classList.remove('visible');

      document.getElementById('cmd-input').addEventListener('input', (e) => renderCmdResults(e.target.value));
      document.getElementById('cmd-overlay').onclick = (e) => {
        if (e.target === document.getElementById('cmd-overlay')) closeCmdPalette();
      };

      const sidebarToggle = document.querySelector('.sidebar-toggle');
      if (sidebarToggle) sidebarToggle.onclick = toggleSidebar;

      window.addEventListener('resize', () => {
        updateSidebarToggle();
        updateScrollTopVisibility();
        renderCharts();
      });
    }

    function toggleSidebar() {
      const sidebar = document.getElementById('sidebar');
      if (window.innerWidth <= 768) sidebar.classList.toggle('mobile-open');
      else sidebar.classList.toggle('collapsed');
      updateSidebarToggle();
      setTimeout(renderCharts, 350);
    }

    function updateSidebarToggle() {
      const sidebar = document.getElementById('sidebar');
      const toggle = document.querySelector('.sidebar-toggle');
      if (!sidebar || !toggle) return;
      if (window.innerWidth <= 768) {
        toggle.textContent = sidebar.classList.contains('mobile-open') ? '⌄' : '⌃';
      } else {
        sidebar.classList.remove('mobile-open');
        toggle.textContent = sidebar.classList.contains('collapsed') ? '›' : '‹';
      }
    }

    function bindKeyboard() {
      document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
          e.preventDefault();
          if (document.getElementById('cmd-overlay').classList.contains('open')) closeCmdPalette();
          else openCmdPalette();
          return;
        }

        if (e.key === 'Escape') {
          closeCmdPalette();
          document.getElementById('compare-panel').classList.remove('open');
          document.getElementById('cell-popover').classList.remove('visible');
          return;
        }

        if (document.getElementById('cmd-overlay').classList.contains('open')) {
          const items = document.querySelectorAll('#cmd-results .cmd-item');
          if (e.key === 'ArrowDown') {
            e.preventDefault();
            cmdSelected = Math.min(cmdSelected + 1, Math.max(items.length - 1, 0));
            items.forEach((el, i) => el.classList.toggle('selected', i === cmdSelected));
            items[cmdSelected]?.scrollIntoView({ block: 'nearest' });
          }
          if (e.key === 'ArrowUp') {
            e.preventDefault();
            cmdSelected = Math.max(cmdSelected - 1, 0);
            items.forEach((el, i) => el.classList.toggle('selected', i === cmdSelected));
            items[cmdSelected]?.scrollIntoView({ block: 'nearest' });
          }
          if (e.key === 'Enter') {
            e.preventDefault();
            items[cmdSelected]?.click();
          }
          return;
        }

        if (e.target.tagName === 'TR') {
          if (e.key === 'ArrowDown') {
            e.preventDefault();
            e.target.nextElementSibling?.focus();
          }
          if (e.key === 'ArrowUp') {
            e.preventDefault();
            e.target.previousElementSibling?.focus();
          }
        }
      });
    }

    // ===== Toast =====
    function toast(msg, type) {
      const container = document.getElementById('toast-container');
      const div = document.createElement('div');
      // Detect type from message or explicit param
      const t = type || (msg.startsWith('✓') || msg.toLowerCase().includes('export') || msg.toLowerCase().includes('copied') || msg.toLowerCase().includes('clear') ? 'success'
        : msg.toLowerCase().includes('error') || msg.toLowerCase().includes('fail') ? 'error' : 'info');
      div.className = 'toast ' + t;
      const icons = {
        success: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
        error: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
        info: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>',
      };
      div.innerHTML = `${icons[t] || icons.info}<span>${escHtml(msg)}</span>`;
      container.appendChild(div);
      setTimeout(() => div.remove(), 3000);
    }

    // ===== Helpers =====
    function escHtml(s) {
      return (s || '').toString()
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    }

    function escRegex(s) {
      return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    '''
).strip()


def build_html() -> str:
    return textwrap.dedent(
        f'''\
        <!DOCTYPE html>
        <html lang="en" data-theme="light">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <meta name="description" content="Interactive RDK-B Component List 2026 workbook viewer">
          <meta name="color-scheme" content="light dark">
          <title>RDK-B Component List 2026</title>
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
          <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
          <style>
        {CSS}
          </style>
        </head>
        <body>
          <div id="progress-bar"></div>
          <div id="toast-container"></div>
          <div id="sr-announce" aria-live="polite" aria-atomic="true"></div>

          <nav id="nav" role="navigation" aria-label="Main navigation">
            <a class="logo" href="#" aria-label="RDK-B Component List Home">
              <div class="logo-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><circle cx="12" cy="20" r="1"/></svg></div>
              <span class="logo-text">RDK-B Component List 2026</span>
              <span id="nav-breadcrumb"></span>
            </a>
            <div class="spacer"></div>
            <button class="nav-btn" id="cmd-btn" aria-label="Command palette (Ctrl+K)"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg> <span>Ctrl+K</span></button>
            <button class="nav-btn" id="export-csv-btn" aria-label="Export CSV"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> <span>CSV</span></button>
            <button class="nav-btn" id="export-json-btn" aria-label="Export JSON"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg> <span>JSON</span></button>
            <button class="nav-btn" id="copy-url-btn" aria-label="Copy URL"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg> <span>Share</span></button>
            <button class="nav-btn" id="print-btn" aria-label="Print"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg></button>
            <button class="nav-btn" id="load-workbook-btn" aria-label="Load a different Excel workbook"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg> <span>Load Workbook</span></button>
            <input type="file" id="workbook-file-input" accept=".xlsx,.xls" style="display:none">
          
            <button class="nav-btn" id="dark-toggle" aria-label="Toggle dark mode"><svg id="dark-toggle-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg></button>
          </nav>

          <div id="app">
            <aside id="sidebar" role="complementary" aria-label="Sidebar">
              <div class="sidebar-section">
                <div class="sidebar-title"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:6px"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>Workbook</div>
                <div id="sidebar-workbook-summary"></div>
              </div>
              <div class="sidebar-section">
                <div class="sidebar-title"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:6px"><path d="M12 3v6"/><path d="M5 8h14"/><path d="M4 14h16"/><path d="M10 14v7"/><path d="M14 14v7"/></svg>Sheets</div>
                <div id="sidebar-sheet-list" class="sidebar-list"></div>
              </div>
              <div class="sidebar-section">
                <div class="sidebar-title"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:6px"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>Quick Actions</div>
                <div id="sidebar-quick-filters" class="sidebar-actions"></div>
              </div>
              <div class="sidebar-section">
                <div class="sidebar-title"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:6px"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>Active View</div>
                <div id="sidebar-active-filters"></div>
              </div>
              <div class="sidebar-section">
                <div class="sidebar-title"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:6px"><path d="M9 18h6"/><path d="M10 22h4"/><path d="M12 2a7 7 0 0 0-4 12.75c.61.43 1 1.12 1 1.88V18h6v-1.37c0-.76.39-1.45 1-1.88A7 7 0 0 0 12 2z"/></svg>Tips</div>
                <div class="sidebar-legend">
                  <div class="legend-item"><span class="legend-dot" style="background:var(--brand-teal)"></span><span>Shift-click headers for multi-sort.</span></div>
                  <div class="legend-item"><span class="legend-dot" style="background:var(--accent-amber)"></span><span>Select 2+ rows to open compare mode.</span></div>
                  <div class="legend-item"><span class="legend-dot" style="background:var(--success)"></span><span>Use <span class="kbd">Ctrl</span> + <span class="kbd">K</span> for quick navigation.</span></div>
                </div>
              </div>
              <div class="sidebar-section">
                <div class="sidebar-title">Legend</div>
                <p class="section-note">Sticky headers, fuzzy search, export tools, visual fill-rate heatmap, row comparison, URL sharing, and light/dark themes are all built into this single-file workbook viewer.</p>
              </div>
            </aside>
            <button class="sidebar-toggle" aria-label="Toggle sidebar">‹</button>

            <main id="main" role="main">
              <div id="sheet-tabs" role="tablist" aria-label="Sheet selection"></div>

              <div id="content-area">
                <div id="workbook-load-panel">
                  <div id="workbook-drop-zone" tabindex="0" role="button" aria-label="Choose or drop an Excel workbook">
                    <div class="wlp-icon">📊</div>
                    <div class="wlp-title">Load the RDK-B component workbook</div>
                    <div class="wlp-sub" id="workbook-load-msg">Drop an .xlsx file here, or click to browse. Next year, just swap in the new file — no rebuild needed.</div>
                    <button class="toolbar-btn" id="workbook-drop-browse-btn" type="button">📁 Choose File</button>
                  </div>
                </div>
                <div id="skeleton-loader">
                  <div class="skeleton" style="height:22px;width:40%;margin-bottom:12px"></div>
                  <div class="skeleton" style="height:84px;margin-bottom:12px"></div>
                  <div class="skeleton" style="height:220px;margin-bottom:12px"></div>
                  <div class="skeleton" style="height:42px;margin-bottom:12px"></div>
                  <div class="skeleton" style="height:320px"></div>
                </div>

                <div id="main-content" style="display:none">
                  <div id="welcome-banner">
                    <div class="welcome-content">
                      <div class="welcome-icon">📡</div>
                      <div>
                        <div class="welcome-title">RDK-B Component List 2026</div>
                        <div class="welcome-sub">Interactive explorer for RDK-B component profiles across Router, Gateway and all deployment configurations.</div>
                        <div class="welcome-chips">
                          <span class="welcome-chip">🔍 Fuzzy Search</span>
                          <span class="welcome-chip">📊 Live Charts</span>
                          <span class="welcome-chip">⬇ CSV / JSON Export</span>
                          <span class="welcome-chip">⌨ Ctrl+K Command Palette</span>
                          <span class="welcome-chip">🌙 Dark Mode</span>
                        </div>
                      </div>
                      <button id="dismiss-banner" aria-label="Dismiss banner">✕</button>
                    </div>
                  </div>

                  <div id="stat-cards" aria-label="Summary statistics"></div>

                  <div id="charts-row">
                    <div class="chart-card">
                      <div class="chart-title">📊 Sub-System Distribution</div>
                      <canvas id="donut-canvas" width="560" height="300" style="width:100%;height:auto;max-height:300px"></canvas>
                      <div style="font-size:0.7rem;color:var(--text-muted);text-align:center;padding-bottom:6px">Click segment to filter · hover to inspect</div>
                    </div>
                    <div class="chart-card">
                      <div class="chart-title">📈 Profile Comparison</div>
                      <canvas id="bar-canvas" width="400" height="180" style="width:100%;height:auto;max-height:180px"></canvas>
                      <div style="font-size:0.7rem;color:var(--text-muted);text-align:center;padding-bottom:6px">Click bar to switch sheet</div>
                    </div>
                  </div>

                  <div id="toolbar">
                    <div id="search-wrapper">
                      <span class="search-icon">🔍</span>
                      <input id="search-input" type="search" placeholder="Search all columns… (fuzzy)" aria-label="Search table data">
                    </div>
                    <button class="toolbar-btn" id="reset-filters-btn">✕ Reset</button>
                    <button class="toolbar-btn" id="group-toggle-btn" aria-pressed="false">⊞ Group</button>
                  </div>

                  <div id="search-history" role="list" aria-label="Search history"></div>
                  <div id="global-search-panel" aria-label="Global search results"></div>

                  <div id="col-vis-panel" class="col-vis-panel" role="group" aria-label="Column visibility"></div>

                  <div id="table-wrapper" role="region" aria-label="Data table">
                    <table id="data-table" role="grid" aria-label="RDK-B Component data">
                      <thead></thead>
                      <tbody></tbody>
                    </table>
                  </div>

                  <nav id="pagination" aria-label="Table pagination"></nav>

                  <footer id="page-footer">
                    <div class="footer-inner">
                      <span>RDK-B Component List 2026</span>
                      <span class="footer-sep">·</span>
                      <a href="https://github.com/cpokuru/CoreRDK-Broadband-Docs" target="_blank" rel="noopener" class="footer-link">View on GitHub ↗</a>
                      <span class="footer-sep">·</span>
                      <span id="footer-stats"></span>
                    </div>
                  </footer>
                </div>
              </div>
            </main>
          </div>

          <div id="kbd-legend" tabindex="0">
            <button type="button" class="kbd-legend-toggle" onclick="this.parentElement.classList.toggle('open')">⌨ Shortcuts <span>▾</span></button>
            <div class="kbd-legend-body">
              <div><span><kbd class="kbd">Ctrl+K</kbd></span><span>Command palette</span></div>
              <div><span><kbd class="kbd">Shift+Click</kbd></span><span>Multi-sort</span></div>
              <div><span><kbd class="kbd">Esc</kbd></span><span>Close panels</span></div>
              <div><span><kbd class="kbd">↑↓</kbd></span><span>Navigate rows</span></div>
            </div>
          </div>

          <button id="scroll-top" aria-label="Scroll to top">↑</button>

          <div id="compare-fab" role="button" tabindex="0" aria-label="Compare selected rows">
            Compare <span class="compare-count">2</span> rows
          </div>

          <aside id="compare-panel" role="complementary" aria-label="Row comparison">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
              <h3>Row Comparison</h3>
              <button id="compare-close" class="toolbar-btn">✕ Close</button>
            </div>
            <div id="compare-body"></div>
          </aside>

          <div id="cell-popover" role="tooltip" aria-label="Cell content">
            <button id="cell-popover-close" aria-label="Close">✕</button>
            <div id="cell-popover-text"></div>
          </div>

          <div id="cmd-overlay" role="dialog" aria-modal="true" aria-label="Command palette">
            <div id="cmd-modal">
              <input id="cmd-input" type="text" placeholder="Search commands and sheets…" aria-label="Command search" autocomplete="off">
              <div id="cmd-results" role="listbox"></div>
            </div>
          </div>

          <script>
        {JS}
          </script>
        </body>
        </html>
        '''
    )


WORKBOOK_NAME = "RDK-B_Component_List_2026.xlsx"


def sync_workbook() -> None:
    """Copy the source .xlsx from the repo's top-level docs/ folder into
    components/ so the page's client-side fetch('RDK-B_Component_List_2026.xlsx')
    — a same-directory relative path — resolves once this is served by
    GitHub Pages. Always re-copies (not just "if missing") so a newer xlsx
    in docs/ is picked up on every build."""
    dest = DOCS_DIR / WORKBOOK_NAME
    source = ROOT.parent / "docs" / WORKBOOK_NAME
    if not source.exists():
        # fall back to the old same-folder convention, in case this script
        # is ever run standalone outside the consolidated repo layout
        source = ROOT / WORKBOOK_NAME
    if not source.exists():
        print(f"WARNING: no {WORKBOOK_NAME} found in ../docs/ or {ROOT}. "
              f"The page's 'Load Workbook' picker will still work, but auto-fetch will fail "
              f"until a matching .xlsx is placed in {DOCS_DIR}.")
        return
    shutil.copy2(source, dest)
    print(f"Copied {source} -> {dest}")


def main() -> None:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--sync-only", action="store_true",
                     help="Only sync the .xlsx into components/ — don't rewrite full-list.html. "
                          "This is what build_site.py calls on every build; full-list.html is a "
                          "committed static template, regenerated with the full run only when the "
                          "page design itself changes.")
    args = ap.parse_args()

    DOCS_DIR.mkdir(parents=True, exist_ok=True)
    if not args.sync_only:
        new_html = build_html()
        HTML_PATH.write_text(new_html, encoding="utf-8")
        print(f"Wrote {HTML_PATH}")
    sync_workbook()


if __name__ == "__main__":
    main()
